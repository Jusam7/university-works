import numpy as np
import matplotlib.pyplot as plt

n = 10000

x = []

for i in range(n):
    u = np.random.rand()
    s = 0
    k = 0
    while True:
        p = 2**(-(k+1))
        s = s + p
        if u <= s:
            x.append(k)
            break
        k += 1

x = np.array(x)

values = np.arange(0, max(x)+1)

hist = []

for v in values:
    hist.append(sum(x == v)/n)

hist = np.array(hist)

p = (2**(-(values+1)))

plt.bar(values, hist)
plt.plot(values, p, 'o-')

plt.show()