import numpy as np
import  matplotlib.pyplot as plt
from scipy.stats import norm

N = 100000

# генерация
u = np.random.rand(N)
x = 1 + u**(1/3)

# математическое ожидание
m_manual = np.sum(x) / N
m_numpy = np.mean(x)

m_theoretical = 1.75

# дисперсия
D_manual = (np.sum(x**2) / (N - 1)) - (np.sum(x)**2) / (N * (N - 1))
D_numpy = np.var(x, ddof = 1)

D_theoretical = 0.0375

# доверительный интервал
alpha = 0.05
z = norm.ppf(1 - alpha/2)
sigma = np.sqrt(D_numpy)

ci_left = m_manual - z * sigma / np.sqrt(N)
ci_right = m_manual + z * sigma / np.sqrt(N)

print("Математическое ожидание:")
print("ручной расчет:", m_manual)
print("numpy mean:", m_numpy)
print("теоретическое:", m_theoretical)

print("\nДисперсия:")
print("ручной расчет:", D_manual)
print("numpy var:", D_numpy)
print("теоретическая:", D_theoretical)

print("\nДоверительный интервал:")
print(ci_left, ci_right)

# графики
x_vals = np.linspace(1, 2, 1000)
pdf = 3 * (x_vals - 1)**2

plt.hist(x, bins=50, density=True, alpha=0.5, label="Эмпирическая плотность")
plt.plot(x_vals, pdf, 'r', label="Теоретическая плотность")
plt.legend()
plt.show()