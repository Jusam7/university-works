import numpy as np
import matplotlib.pyplot as plt
import math

lam = 0.5
T = 3
N = 100000

all_times = []
counts = []

for j in range(N):
    t = 0
    times = []
    while True:
        t = t - np.log(np.random.rand())/lam
        if t > T:
            break
        times.append(t)
    all_times.append(times)
    counts.append(len(times))

m = 10
dt = T/m

ni = [0]*m

for times in all_times:
    for t in times:
        i = int(t/dt)
        if i < m:
            ni[i] += 1

lam_est = []

for i in range(m):
    lam_est.append(ni[i]/(N*dt))

t_vals = np.linspace(0,T,m)

plt.plot(t_vals, lam_est, 'o-')
plt.plot(t_vals, [lam]*m)

plt.show()

counts = np.array(counts)

k_vals = np.arange(0, max(counts)+1)

Nk = []

for k in k_vals:
    Nk.append(sum(counts == k))

Pk = np.array(Nk)/N

Delta = lam*T

P_theor = []

for k in k_vals:
    P_theor.append((Delta**k/math.factorial(k))*np.exp(-Delta))

plt.bar(k_vals, Pk)
plt.plot(k_vals, P_theor, 'o-')

plt.show()