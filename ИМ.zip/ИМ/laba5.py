import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chisquare

k = np.array([3, 5, 7, 9])
p = np.array([0.35, 0.15, 0.35, 0.15])

N = 10000

F = np.cumsum(p)


u = np.random.rand(N)
sample = np.zeros(N)

for i in range(N):
    for j in range(len(F)):
        if u[i] <= F[j]:
            sample[i] = k[j]
            break

M_theor = np.sum(k * p)
D_theor = np.sum(k**2 * p) - M_theor**2

M_emp = np.mean(sample)
D_emp = np.var(sample)

print("Теоретическое мат. ожидание:", M_theor)
print("Эмпирическое мат. ожидание:", M_emp)
print()

print("Теоретическая дисперсия:", D_theor)
print("Эмпирическая дисперсия:", D_emp)
print()

unique, counts = np.unique(sample, return_counts=True)
p_emp = counts / N

plt.figure()

plt.bar(k - 0.2, p, width=0.4, label="Теоретическое")

plt.bar(unique + 0.2, p_emp, width=0.4, label="Эмпирическое")

plt.xlabel("k")
plt.ylabel("P")
plt.legend()
plt.title("Сравнение распределений")
plt.show()

expected = N * p
observed = counts

chi2_stat, p_value = chisquare(f_obs=observed, f_exp=expected)

print("Статистика хи-квадрат:", chi2_stat)
print("p-value:", p_value)

alpha = 0.05
if p_value > alpha:
    print("Гипотеза НЕ отвергается")
else:
    print("Гипотеза отвергается")