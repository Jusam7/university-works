import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2

def f(x):
    return 3 * np.sin(x) * (np.cos(x) ** 2)

a = 0
b = np.pi / 2
N = 10000

M = max(f(np.linspace(a, b, 10000)))

samples = []
while len(samples) < N:
    x = np.random.uniform(a, b)
    y = np.random.uniform(0, M)
    if y <= f(x):
        samples.append(x)

samples = np.array(samples)

x_vals = np.linspace(a, b, 500)
plt.hist(samples, bins=50, density=True, alpha=0.5, label="Эмпирическая")
plt.plot(x_vals, f(x_vals), 'r', label="Теоретическая")
plt.legend()
plt.title("Сравнение плотностей")
plt.show()

k = 20
hist, edges = np.histogram(samples, bins=k)


p = []
for i in range(k):
    x1, x2 = edges[i], edges[i+1]
    xs = np.linspace(x1, x2, 100)
    px = np.trapezoid(f(xs), xs)
    p.append(px)

p = np.array(p)
expected = N * p

chi2_stat = np.sum((hist - expected) ** 2 / expected)

alpha = 0.05
df = k - 1
chi2_crit = chi2.ppf(1 - alpha, df)

print("χ^2 статистика:", chi2_stat)
print("χ^2 критическое:", chi2_crit)
print("Гипотеза принята:", chi2_stat < chi2_crit)

samples_sorted = np.sort(samples)

def F(x):
    return 1 - (np.cos(x) ** 3)

omega2 = 0
for i in range(N):
    Fi = F(samples_sorted[i])
    omega2 += (Fi - (2*i + 1)/(2*N))**2

omega2 += 1/(12*N)

print("omega^2:", omega2)