import java.util.Comparator;

/**
 * Компаратор для сортировки по длине названия продукта (вариант 3).
 */
public class FoodComparator implements Comparator<Food> {
    @Override
    public int compare(Food f1, Food f2) {
        if (f1 == null) return 1;
        if (f2 == null) return -1;
        return Integer.compare(f1.getName().length(), f2.getName().length());
    }
}
