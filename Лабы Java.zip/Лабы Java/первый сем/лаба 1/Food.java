public abstract class Food implements Consumable {
    protected String name;

    public Food(String name) {
        this.name = name;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Food)) return false;
        Food other = (Food) obj;
        return name != null && name.equals(other.name);
    }

    @Override
    public String toString() {
        return name;
    }
}
