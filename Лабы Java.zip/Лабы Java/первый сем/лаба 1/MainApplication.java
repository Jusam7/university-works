import java.util.Arrays;

public class MainApplication {
    public static void main(String[] args) {
        Food[] breakfast = new Food[20];
        int count = 0;
        boolean sort = false;
        boolean showCalories = false;

        for (String arg : args) {
            if (arg.equals("-sort")) {
                sort = true;
                continue;
            }
            if (arg.equals("-calories")) {
                showCalories = true;
                continue;
            }

            String[] parts = arg.split("/");
            switch (parts[0]) {
                case "Milk":
                    if (parts.length > 1)
                        breakfast[count++] = new Milk(parts[1]);
                    else
                        breakfast[count++] = new Milk("2.5%");
                    break;

                case "Cheese":
                    breakfast[count++] = new Cheese();
                    break;

                case "Apple":
                    if (parts.length > 1)
                        breakfast[count++] = new Apple(parts[1]);
                    break;
            }
        }

        if (sort) {
            Arrays.sort(breakfast, new FoodComparator());
        }

        double totalCalories = 0;
        for (Food f : breakfast) {
            if (f == null) break;
            f.consume();
            if (f instanceof Nutritious)
                totalCalories += ((Nutritious) f).calculateCalories();
        }

        if (showCalories)
            System.out.println("Общая калорийность завтрака: " + totalCalories + " ккал");
    }
}
