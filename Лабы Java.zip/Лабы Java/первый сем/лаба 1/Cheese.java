/**
 * Класс "Сыр"
 */
public class Cheese extends Food {

    public Cheese() {
        super("Сыр");
    }

    // Реализация метода употребления
    @Override
    public void consume() {
        System.out.println(this + " съеден");
    }
}
