public class Milk extends Food implements Nutritious {
    private String fat; // жирность в процентах

    public Milk(String fat) {
        super("Молоко");
        this.fat = fat;
    }

    public String getFat() { return fat; }

    public void setFat(String fat) { this.fat = fat; }

    @Override
    public void consume() {
        System.out.println(this + " выпито");
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Milk)) return false;
        return fat.equals(((Milk) obj).fat);
    }

    @Override
    public String toString() {
        return super.toString() + " жирности " + fat;
    }

    @Override
    public double calculateCalories() {
        // приблизительно: 1% жирности ≈ 60 ккал/100 мл
        switch (fat) {
            case "1.5%": return 60.0;
            case "2.5%": return 80.0;
            case "5%":   return 120.0;
            default:     return 70.0;
        }
    }
}
