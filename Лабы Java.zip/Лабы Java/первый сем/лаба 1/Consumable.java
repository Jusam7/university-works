/**
 * Интерфейс для всех употребляемых объектов.
 */
public interface Consumable {
    void consume();
}
