/**
 * Интерфейс для объектов, обладающих калорийностью.
 */
public interface Nutritious {
    double calculateCalories();
}
