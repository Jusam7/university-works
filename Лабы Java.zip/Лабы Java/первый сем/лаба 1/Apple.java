/**
 * Класс "Яблоко", наследуется от Food
 */
public class Apple extends Food {

    private String size; // Размер яблока

    public Apple(String size) {
        super("Яблоко");
        this.size = size;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    // Реализация метода употребления
    @Override
    public void consume() {
        System.out.println(this + " съедено");
    }

    // Переопределение toString()
    @Override
    public String toString() {
        return super.toString() + " размера '" + size.toUpperCase() + "'";
    }

    // Проверка равенства с учётом размера
    @Override
    public boolean equals(Object arg0) {
        if (super.equals(arg0)) {
            if (!(arg0 instanceof Apple)) return false;
            return size.equals(((Apple) arg0).size);
        } else
            return false;
    }
}

