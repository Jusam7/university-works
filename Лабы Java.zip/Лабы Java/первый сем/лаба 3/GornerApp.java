// Файл: GornerApp.java
// Компиляция: javac GornerApp.java
// Запуск: java GornerApp 1 -3 2   (пример коэффициентов: x^2 - 3x + 2)

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.Locale;

public class GornerApp {

    // ----- Главный фрейм приложения -----
    public static class MainFrame extends JFrame {
        private static final int WIDTH = 800;
        private static final int HEIGHT = 600;

        private Double[] coefficients;
        private JFileChooser fileChooser = null;

        private JMenuItem saveToTextMenuItem;
        private JMenuItem saveToGraphicsMenuItem;
        private JMenuItem searchValueMenuItem;

        private JTextField textFieldFrom;
        private JTextField textFieldTo;
        private JTextField textFieldStep;

        private Box hBoxResult;
        private GornerTableModel data;
        private GornerTableCellRenderer renderer = new GornerTableCellRenderer();

        public MainFrame(Double[] coefficients) {
            super("Табулирование многочлена (с краевой симметрией)");
            this.coefficients = coefficients;
            setSize(WIDTH, HEIGHT);
            Toolkit kit = Toolkit.getDefaultToolkit();
            setLocation((kit.getScreenSize().width - WIDTH)/2,
                    (kit.getScreenSize().height - HEIGHT)/2);

            // --- меню ---
            JMenuBar menuBar = new JMenuBar();
            setJMenuBar(menuBar);

            JMenu fileMenu = new JMenu("Файл");
            menuBar.add(fileMenu);

            JMenu tableMenu = new JMenu("Таблица");
            menuBar.add(tableMenu);

            JMenu helpMenu = new JMenu("Справка");
            menuBar.add(helpMenu);

            // Сохранить в текстовый файл
            Action saveToTextAction = new AbstractAction("Сохранить в текстовый файл") {
                public void actionPerformed(ActionEvent event) {
                    if (fileChooser == null) {
                        fileChooser = new JFileChooser();
                        fileChooser.setCurrentDirectory(new File("."));
                    }
                    if (fileChooser.showSaveDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) {
                        saveToTextFile(fileChooser.getSelectedFile());
                    }
                }
            };
            saveToTextMenuItem = fileMenu.add(saveToTextAction);
            saveToTextMenuItem.setEnabled(false);

            // Сохранить данные для построения графика (двоичный)
            Action saveToGraphicsAction = new AbstractAction("Сохранить данные для построения графика") {
                public void actionPerformed(ActionEvent event) {
                    if (fileChooser == null) {
                        fileChooser = new JFileChooser();
                        fileChooser.setCurrentDirectory(new File("."));
                    }
                    if (fileChooser.showSaveDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) {
                        saveToGraphicsFile(fileChooser.getSelectedFile());
                    }
                }
            };
            saveToGraphicsMenuItem = fileMenu.add(saveToGraphicsAction);
            saveToGraphicsMenuItem.setEnabled(false);

            // Поиск значения
            Action searchValueAction = new AbstractAction("Найти значение многочлена") {
                public void actionPerformed(ActionEvent event) {
                    String value = JOptionPane.showInputDialog(MainFrame.this,
                            "Введите значение для поиска (строковое представление):",
                            "Поиск значения", JOptionPane.QUESTION_MESSAGE);
                    renderer.setNeedle(value);
                    getContentPane().repaint();
                }
            };
            searchValueMenuItem = tableMenu.add(searchValueAction);
            searchValueMenuItem.setEnabled(false);

            // О программе
            Action aboutAction = new AbstractAction("О программе") {
                public void actionPerformed(ActionEvent event) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "Автор: Радкевич Станислав\nГруппа: Группа №8 \nЛабораторная: №3, задание 4.2 Вариант B (краевая симметрия)",
                            "О программе", JOptionPane.INFORMATION_MESSAGE);
                }
            };
            helpMenu.add(aboutAction);

            // --- верхняя панель ввода параметров ---
            Box hboxTop = Box.createHorizontalBox();
            hboxTop.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
            hboxTop.add(new JLabel("От: "));
            textFieldFrom = new JTextField("0.0", 8);
            hboxTop.add(textFieldFrom);
            hboxTop.add(Box.createHorizontalStrut(10));
            hboxTop.add(new JLabel("До: "));
            textFieldTo = new JTextField("1.0", 8);
            hboxTop.add(textFieldTo);
            hboxTop.add(Box.createHorizontalStrut(10));
            hboxTop.add(new JLabel("Шаг: "));
            textFieldStep = new JTextField("0.1", 8);
            hboxTop.add(textFieldStep);

            getContentPane().add(hboxTop, BorderLayout.NORTH);

            // --- центральная область для результатов ---
            hBoxResult = Box.createHorizontalBox();
            hBoxResult.add(new JPanel());
            getContentPane().add(hBoxResult, BorderLayout.CENTER);

            // --- нижняя панель с кнопками ---
            JButton buttonCalc = new JButton("Вычислить");
            buttonCalc.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                    try {
                        Double from = Double.parseDouble(textFieldFrom.getText());
                        Double to = Double.parseDouble(textFieldTo.getText());
                        Double step = Double.parseDouble(textFieldStep.getText());
                        data = new GornerTableModel(from, to, step, MainFrame.this.coefficients);
                        JTable table = new JTable(data);
                        // Визуализатор для Double
                        table.setDefaultRenderer(Double.class, renderer);
                        table.setRowHeight(30);
                        // Boolean будет отображаться как JCheckBox автоматически
                        hBoxResult.removeAll();
                        hBoxResult.add(new JScrollPane(table));
                        getContentPane().validate();
                        saveToTextMenuItem.setEnabled(true);
                        saveToGraphicsMenuItem.setEnabled(true);
                        searchValueMenuItem.setEnabled(true);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(MainFrame.this,
                                "Ошибка в формате записи числа с плавающей точкой",
                                "Ошибочный формат числа", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });

            JButton buttonReset = new JButton("Очистить поля");
            buttonReset.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                    textFieldFrom.setText("0.0");
                    textFieldTo.setText("1.0");
                    textFieldStep.setText("0.1");
                    hBoxResult.removeAll();
                    hBoxResult.add(new JPanel());
                    saveToTextMenuItem.setEnabled(false);
                    saveToGraphicsMenuItem.setEnabled(false);
                    searchValueMenuItem.setEnabled(false);
                    getContentPane().validate();
                }
            });

            Box hboxButtons = Box.createHorizontalBox();
            hboxButtons.setBorder(BorderFactory.createBevelBorder(1));
            hboxButtons.add(Box.createHorizontalGlue());
            hboxButtons.add(buttonCalc);
            hboxButtons.add(Box.createHorizontalStrut(30));
            hboxButtons.add(buttonReset);
            hboxButtons.add(Box.createHorizontalGlue());
            hboxButtons.setPreferredSize(new Dimension(
                    new Double(hboxButtons.getMaximumSize().getWidth()).intValue(),
                    new Double(hboxButtons.getMinimumSize().getHeight()).intValue()*2));
            getContentPane().add(hboxButtons, BorderLayout.SOUTH);
        }

        // Запись в текстовый файл (человекочитаемый)
        protected void saveToTextFile(File selectedFile) {
            try {
                PrintStream out = new PrintStream(selectedFile, "UTF-8");
                out.println("Результаты табулирования многочлена по схеме Горнера");
                out.print("Многочлен: ");
                for (int i = 0; i < coefficients.length; i++) {
                    out.print(coefficients[i] + "*X^" + (coefficients.length - i - 1));
                    if (i != coefficients.length - 1) out.print(" + ");
                }
                out.println();
                out.println("Интервал от " + data.getFrom() + " до " + data.getTo() +
                        " с шагом " + data.getStep());
                out.println("================================================");
                DecimalFormat df = new DecimalFormat();
                df.setMaximumFractionDigits(5);
                df.setGroupingUsed(false);
                DecimalFormatSymbols s = df.getDecimalFormatSymbols();
                s.setDecimalSeparator('.');
                df.setDecimalFormatSymbols(s);

                for (int i = 0; i < data.getRowCount(); i++) {
                    out.println("Значение в точке " + df.format(data.getValueAt(i, 0)) +
                            " равно " + df.format(data.getValueAt(i, 1)) +
                            "  Краевая симметрия: " + data.getValueAt(i, 2));
                }
                out.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Ошибка при сохранении в текстовый файл",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }

        // Сохранение в двоичный файл: x,y пары (double)
        protected void saveToGraphicsFile(File selectedFile) {
            try {
                DataOutputStream out = new DataOutputStream(new FileOutputStream(selectedFile));
                for (int i = 0; i < data.getRowCount(); i++) {
                    out.writeDouble((Double) data.getValueAt(i, 0)); // x
                    out.writeDouble((Double) data.getValueAt(i, 1)); // y
                }
                out.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Ошибка при сохранении в двоичный файл",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ----- Модель таблицы (с дополнительным 3-м столбцом: "Краевая симметрия") -----
    public static class GornerTableModel extends AbstractTableModel {
        private Double[] coefficients;
        private Double from;
        private Double to;
        private Double step;

        public GornerTableModel(Double from, Double to, Double step, Double[] coefficients) {
            this.from = from;
            this.to = to;
            this.step = step;
            this.coefficients = coefficients;
        }

        public Double getFrom() { return from; }
        public Double getTo() { return to; }
        public Double getStep() { return step; }

        @Override
        public int getColumnCount() { return 3; } // X, value, краевая симметрия

        @Override
        public int getRowCount() {
            if (step <= 0 || to < from) return 0;
            return (int)Math.floor((to - from) / step) + 1;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            double x = from + step * rowIndex;
            if (columnIndex == 0) {
                return x;
            } else if (columnIndex == 1) {
                // вычисление по схеме Горнера; коэффициенты с старшей степени в начале
                double result = 0.0;
                for (int i = 0; i < coefficients.length; i++) {
                    result = result * x + coefficients[i];
                }
                return result;
            } else {
                // третий столбец: краевая симметрия
                double value = (Double)getValueAt(rowIndex, 1);
                String digits = digitsOnly(value);
                if (digits.length() == 0) return Boolean.FALSE;
                char first = digits.charAt(0);
                char last = digits.charAt(digits.length()-1);
                return first == last;
            }
        }

        // Возвращаем только цифровые символы (без знака и точки)
        private String digitsOnly(double v) {
            // форматируем число так, чтобы не было экспоненты
            DecimalFormat df = new DecimalFormat();
            df.setMaximumFractionDigits(10);
            df.setGroupingUsed(false);
            DecimalFormatSymbols s = df.getDecimalFormatSymbols();
            s.setDecimalSeparator('.');
            df.setDecimalFormatSymbols(s);
            String sVal = df.format(Math.abs(v));
            StringBuilder sb = new StringBuilder();
            for (char c : sVal.toCharArray()) {
                if (Character.isDigit(c)) sb.append(c);
            }
            return sb.toString();
        }

        @Override
        public Class<?> getColumnClass(int col) {
            switch (col) {
                case 0: return Double.class;
                case 1: return Double.class;
                default: return Boolean.class;
            }
        }

        @Override
        public String getColumnName(int col) {
            switch (col) {
                case 0: return "Значение X";
                case 1: return "Значение многочлена";
                default: return "Краевая симметрия";
            }
        }
    }

    // ----- Визуализатор ячеек (цвет для суммы цифр целой части, а также подсветка при поиске) -----
    public static class GornerTableCellRenderer implements TableCellRenderer {
        private JPanel panel = new JPanel();
        private JLabel label = new JLabel();
        private DecimalFormat formatter = (DecimalFormat)NumberFormat.getInstance(Locale.US);
        private String needle = null;

        public GornerTableCellRenderer() {
            panel.setLayout(new FlowLayout(FlowLayout.LEFT));
            panel.add(label);
            formatter.setMaximumFractionDigits(5);
            formatter.setGroupingUsed(false);
            DecimalFormatSymbols s = formatter.getDecimalFormatSymbols();
            s.setDecimalSeparator('.');
            formatter.setDecimalFormatSymbols(s);
        }

        public void setNeedle(String needle) {
            this.needle = (needle != null && needle.trim().length() > 0) ? needle.trim() : null;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int col) {
            if (value == null) {
                label.setText("");
                panel.setBackground(Color.WHITE);
                return panel;
            }
            if (col == 0 || col == 1) {
                String formatted = formatter.format(value);
                label.setText(formatted);

                // Если needle задана и совпадает со строковым представлением - красим в красный
                if (col == 1 && needle != null && needle.equals(formatted)) {
                    panel.setBackground(Color.RED);
                } else {
                    // Иначе проверяем: сумма цифр целой части делится на 10 -> специальный цвет
                    if (col == 1) {
                        long intPart = Math.abs(((Double)value).longValue());
                        int sum = sumDigits(intPart);
                        if (sum % 10 == 0 && sum != 0) {
                            panel.setBackground(new Color(173, 216, 230)); // светло-голубой
                        } else {
                            panel.setBackground(Color.WHITE);
                        }
                    } else {
                        panel.setBackground(Color.WHITE);
                    }
                }
                return panel;
            } else {
                // Для Boolean пусть используется стандартный renderer (поскольку таблица сама подберёт),
                // но этот метод вызывается только т.к. мы назначаем renderer для Double.class.
                label.setText(value.toString());
                panel.setBackground(Color.WHITE);
                return panel;
            }
        }

        private int sumDigits(long n) {
            int s = 0;
            while (n > 0) {
                s += n % 10;
                n /= 10;
            }
            return s;
        }
    }

    // ----- main -----
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Невозможно табулировать многочлен: не заданы коэффициенты в командной строке.");
            System.out.println("Пример запуска: java GornerApp 1 -3 2   (каждый аргумент — коэффициент, начиная со старшего)");
            System.exit(-1);
        }
        Double[] coefficients = new Double[args.length];
        int i = 0;
        try {
            for (String arg : args) coefficients[i++] = Double.parseDouble(arg);
        } catch (NumberFormatException ex) {
            System.out.println("Ошибка преобразования строки '" + args[i] + "' в Double");
            System.exit(-2);
        }

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame(coefficients);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
