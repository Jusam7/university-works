import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class MainApp extends JFrame {

    private static final int WIDTH = 500;
    private static final int HEIGHT = 400;

    private final JTextField textFieldX;
    private final JTextField textFieldY;
    private final JTextField textFieldZ;


    private final JTextField textFieldResult;

    // Группы радио-кнопок
    private final ButtonGroup radioButtonsFormula = new ButtonGroup();
    private final ButtonGroup radioButtonsMemory = new ButtonGroup();

    //  радио-кнопки
    private final Box hboxFormulaType = Box.createHorizontalBox();
    private final Box hboxMemorySelect = Box.createHorizontalBox();

    private int formulaId = 1;
    private int activeMemId = 1;

    // Внутренняя память
    private Double mem1 = 0.0;
    private Double mem2 = 0.0;
    private Double mem3 = 0.0;


    // Формула №1
    private Double calculate1(Double x, Double y, Double z) {
        double innerSin = Math.sin(z * Math.PI * Math.PI); // sin(z * p^2), где p = PI
        double firstPart = Math.sin(Math.log(y) + innerSin);
        double rootBase = x * x + Math.sin(z) + Math.exp(Math.cos(z));
        double fourthRoot = Math.pow(rootBase, 0.25); // корень 4-й степени
        return firstPart * fourthRoot;
    }

    // Формула №2: F(x, y, z) = (1 + x^z + ln y^2) / sqrt(x^3 + 1) * (1 - sin(y * z))
    private Double calculate2(Double x, Double y, Double z) {
        double numerator = 1 + Math.pow(x, z) + Math.log(y * y);
        double denominator = Math.sqrt(Math.pow(x, 3) + 1);
        double secondPart = 1 - Math.sin(y * z);
        return (numerator / denominator) * secondPart;
    }



    // Добавление радио-кнопки выбора формулы
    private void addFormulaRadioButton(String buttonName, final int formulaId) {
        JRadioButton button = new JRadioButton(buttonName);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                MainApp.this.formulaId = formulaId;
            }
        });
        radioButtonsFormula.add(button);
        hboxFormulaType.add(button);
    }


    private void addMemoryRadioButton(String buttonName, final int memId) {
        JRadioButton button = new JRadioButton(buttonName);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                MainApp.this.activeMemId = memId;
            }
        });
        radioButtonsMemory.add(button);
        hboxMemorySelect.add(button);
    }


    public MainApp() {
        super("Вычисление формул с памятью");
        setSize(WIDTH, HEIGHT);
        Toolkit kit = Toolkit.getDefaultToolkit();
        setLocation((kit.getScreenSize().width - WIDTH) / 2,
                (kit.getScreenSize().height - HEIGHT) / 2);

        hboxFormulaType.add(Box.createHorizontalGlue());
        addFormulaRadioButton("Формула 1", 1);
        addFormulaRadioButton("Формула 2", 2);
        radioButtonsFormula.setSelected(
                radioButtonsFormula.getElements().nextElement().getModel(), true);
        hboxFormulaType.add(Box.createHorizontalGlue());
        hboxFormulaType.setBorder(BorderFactory.createTitledBorder("Выбор формулы"));

        JLabel labelForX = new JLabel("X:");
        textFieldX = new JTextField("0", 10);
        JLabel labelForY = new JLabel("Y:");
        textFieldY = new JTextField("0", 10);
        JLabel labelForZ = new JLabel("Z:");
        textFieldZ = new JTextField("0", 10);

        Box hboxVariables = Box.createHorizontalBox();
        hboxVariables.add(Box.createHorizontalGlue());
        hboxVariables.add(labelForX);
        hboxVariables.add(Box.createHorizontalStrut(10));
        hboxVariables.add(textFieldX);
        hboxVariables.add(Box.createHorizontalStrut(20));
        hboxVariables.add(labelForY);
        hboxVariables.add(Box.createHorizontalStrut(10));
        hboxVariables.add(textFieldY);
        hboxVariables.add(Box.createHorizontalStrut(20));
        hboxVariables.add(labelForZ);
        hboxVariables.add(Box.createHorizontalStrut(10));
        hboxVariables.add(textFieldZ);
        hboxVariables.add(Box.createHorizontalGlue());
        hboxVariables.setBorder(BorderFactory.createTitledBorder("Введите X, Y, Z"));

        JLabel labelForResult = new JLabel("Результат:");
        textFieldResult = new JTextField("0", 15);
        Box hboxResult = Box.createHorizontalBox();
        hboxResult.add(Box.createHorizontalGlue());
        hboxResult.add(labelForResult);
        hboxResult.add(Box.createHorizontalStrut(10));
        hboxResult.add(textFieldResult);
        hboxResult.add(Box.createHorizontalGlue());
        hboxResult.setBorder(BorderFactory.createTitledBorder("Результат вычисления"));

        // ---------- Кнопки вычисления ----------
        JButton buttonCalc = new JButton("Вычислить");
        buttonCalc.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                try {
                    Double x = Double.parseDouble(textFieldX.getText());
                    Double y = Double.parseDouble(textFieldY.getText());
                    Double z = Double.parseDouble(textFieldZ.getText());
                    Double result;
                    if (formulaId == 1)
                        result = calculate1(x, y, z);
                    else
                        result = calculate2(x, y, z);
                    textFieldResult.setText(result.toString());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(MainApp.this,
                            "Ошибка ввода числа", "Ошибка", JOptionPane.WARNING_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(MainApp.this,
                            "Ошибка вычисления: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton buttonReset = new JButton("Очистить поля");
        buttonReset.addActionListener(e -> {
            textFieldX.setText("0");
            textFieldY.setText("0");
            textFieldZ.setText("0");
            textFieldResult.setText("0");
        });

        Box hboxButtons = Box.createHorizontalBox();
        hboxButtons.add(Box.createHorizontalGlue());
        hboxButtons.add(buttonCalc);
        hboxButtons.add(Box.createHorizontalStrut(30));
        hboxButtons.add(buttonReset);
        hboxButtons.add(Box.createHorizontalGlue());


        hboxMemorySelect.add(Box.createHorizontalGlue());
        addMemoryRadioButton("Переменная 1", 1);
        addMemoryRadioButton("Переменная 2", 2);
        addMemoryRadioButton("Переменная 3", 3);
        radioButtonsMemory.setSelected(
                radioButtonsMemory.getElements().nextElement().getModel(), true);
        hboxMemorySelect.add(Box.createHorizontalGlue());
        hboxMemorySelect.setBorder(BorderFactory.createTitledBorder("Активная память"));

        JButton buttonMC = new JButton("MC");
        JButton buttonMPlus = new JButton("M+");


        buttonMC.addActionListener(e -> {
            switch (activeMemId) {
                case 1 -> mem1 = 0.0;
                case 2 -> mem2 = 0.0;
                case 3 -> mem3 = 0.0;
            }
            textFieldResult.setText("0");
        });


        buttonMPlus.addActionListener(e -> {
            try {
                Double value = Double.parseDouble(textFieldResult.getText());
                switch (activeMemId) {
                    case 1 -> {
                        mem1 += value;
                        textFieldResult.setText(mem1.toString()); // Выводим обновленное значение памяти
                    }
                    case 2 -> {
                        mem2 += value;
                        textFieldResult.setText(mem2.toString());
                    }
                    case 3 -> {
                        mem3 += value;
                        textFieldResult.setText(mem3.toString());
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(MainApp.this,
                        "Некорректное значение результата", "Ошибка", JOptionPane.WARNING_MESSAGE);
            }
        });

        Box hboxMemoryButtons = Box.createHorizontalBox();
        hboxMemoryButtons.add(Box.createHorizontalGlue());
        hboxMemoryButtons.add(buttonMC);
        hboxMemoryButtons.add(Box.createHorizontalStrut(30));
        hboxMemoryButtons.add(buttonMPlus);
        hboxMemoryButtons.add(Box.createHorizontalGlue());
        hboxMemoryButtons.setBorder(BorderFactory.createTitledBorder("Управление памятью"));

        Box contentBox = Box.createVerticalBox();
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxFormulaType);
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxVariables);
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxResult);
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxButtons);
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxMemorySelect);
        contentBox.add(Box.createVerticalStrut(10));
        contentBox.add(hboxMemoryButtons);
        contentBox.add(Box.createVerticalStrut(10));

        getContentPane().add(contentBox, BorderLayout.CENTER);
    }


    public static void main(String[] args) {
        MainApp frame = new MainApp();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
