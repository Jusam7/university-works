import numpy as np
import matplotlib.pyplot as plt

a = 0.5                      # µm
ns, n1, n0 = 3.2, 3.4, 3.1   # given indices

x = np.linspace(-3*a, 3*a, 1001)

n = np.piecewise(x,
                 [x < -a, (x >= -a) & (x <= a), x > a],
                 [ns, n1, n0])

plt.figure(figsize=(5,3))
plt.plot(x, n, lw=2, color='tab:blue')
plt.xlabel('x, µm')
plt.ylabel('refractive index n')
plt.ylim(3.0, 3.5)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()