import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.event.*;
import java.util.ArrayList;

public class GraphPanel extends JPanel {
    private ArrayList<Point2D.Double> points;
    private boolean highlightEvenIntegerPoints = false;
    private double minX, maxX, minY, maxY;
    private double originalMinX, originalMaxX, originalMinY, originalMaxY;

    // Для масштабирования
    private Point startDragPoint;
    private Point endDragPoint;
    private boolean isDragging = false;
    private Rectangle zoomRect;

    // Для подсказки с координатами
    private String tooltipText = "";
    private Point tooltipPoint = new Point();
    private boolean showTooltip = false;

    public GraphPanel() {
        points = new ArrayList<>();
        setBackground(Color.WHITE);

        // Добавляем слушатели мыши
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                checkPointHover(e.getPoint());
                repaint();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (isDragging) {
                    endDragPoint = e.getPoint();
                    updateZoomRectangle();
                    repaint();
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    // Начало выделения области
                    startDragPoint = e.getPoint();
                    endDragPoint = e.getPoint();
                    isDragging = true;
                    zoomRect = new Rectangle(startDragPoint);
                } else if (e.getButton() == MouseEvent.BUTTON3) {
                    // Правая кнопка - восстановление масштаба
                    resetZoom();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1 && isDragging) {
                    isDragging = false;
                    endDragPoint = e.getPoint();

                    // Применяем масштабирование только если область достаточно большая
                    if (Math.abs(endDragPoint.x - startDragPoint.x) > 10 &&
                            Math.abs(endDragPoint.y - startDragPoint.y) > 10) {
                        applyZoom();
                    }
                    zoomRect = null;
                    repaint();
                }
            }
        });
    }

    public void setPoints(ArrayList<Point2D.Double> points, double minX, double maxX, double minY, double maxY) {
        this.points = points;
        this.minX = minX;
        this.maxX = maxX;
        this.minY = minY;
        this.maxY = maxY;

        // Сохраняем оригинальные значения для восстановления
        this.originalMinX = minX;
        this.originalMaxX = maxX;
        this.originalMinY = minY;
        this.originalMaxY = maxY;

        repaint();
    }

    public void setHighlightEvenIntegerPoints(boolean highlight) {
        this.highlightEvenIntegerPoints = highlight;
        repaint();
    }

    private void checkPointHover(Point mousePoint) {
        showTooltip = false;

        for (Point2D.Double p : points) {
            int x = (int) mapX(p.x);
            int y = (int) mapY(p.y);

            // Проверяем, находится ли курсор рядом с точкой (в радиусе 10 пикселей)
            if (Math.abs(mousePoint.x - x) < 10 && Math.abs(mousePoint.y - y) < 10) {
                tooltipText = String.format("X=%.3f, Y=%.3f", p.x, p.y);
                tooltipPoint.setLocation(mousePoint.x + 10, mousePoint.y - 10);
                showTooltip = true;
                return;
            }
        }
    }

    private void updateZoomRectangle() {
        if (startDragPoint != null && endDragPoint != null) {
            int x = Math.min(startDragPoint.x, endDragPoint.x);
            int y = Math.min(startDragPoint.y, endDragPoint.y);
            int width = Math.abs(endDragPoint.x - startDragPoint.x);
            int height = Math.abs(endDragPoint.y - startDragPoint.y);
            zoomRect = new Rectangle(x, y, width, height);
        }
    }

    private void applyZoom() {
        if (startDragPoint == null || endDragPoint == null) return;

        // Преобразуем экранные координаты в мировые
        double worldX1 = inverseMapX(startDragPoint.x);
        double worldY1 = inverseMapY(startDragPoint.y);
        double worldX2 = inverseMapX(endDragPoint.x);
        double worldY2 = inverseMapY(endDragPoint.y);

        // Определяем границы новой области
        double newMinX = Math.min(worldX1, worldX2);
        double newMaxX = Math.max(worldX1, worldX2);
        double newMinY = Math.min(worldY1, worldY2);
        double newMaxY = Math.max(worldY1, worldY2);

        // Устанавливаем новые границы
        minX = newMinX;
        maxX = newMaxX;
        minY = newMinY;
        maxY = newMaxY;

        repaint();
    }

    private void resetZoom() {
        minX = originalMinX;
        maxX = originalMaxX;
        minY = originalMinY;
        maxY = originalMaxY;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Рисуем оси координат
        drawAxes(g2d);

        // Рисуем точки и линии
        drawGraph(g2d);

        // Рисуем прямоугольник выделения
        if (isDragging && zoomRect != null) {
            drawZoomRectangle(g2d);
        }

        // Рисуем подсказку с координатами
        if (showTooltip) {
            drawTooltip(g2d);
        }
    }

    private void drawAxes(Graphics2D g2d) {
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(Color.BLACK);

        // Оси
        g2d.drawLine(0, (int) mapY(0), width, (int) mapY(0));
        g2d.drawLine((int) mapX(0), 0, (int) mapX(0), height);

        // Подписи осей
        g2d.drawString(String.format("%.1f", minX), 10, (int) mapY(0) + 15);
        g2d.drawString(String.format("%.1f", maxX), width - 30, (int) mapY(0) + 15);
        g2d.drawString(String.format("%.1f", minY), (int) mapX(0) + 5, height - 10);
        g2d.drawString(String.format("%.1f", maxY), (int) mapX(0) + 5, 20);

        // Точка (0,0) если входит в диапазон
        if (minX <= 0 && maxX >= 0 && minY <= 0 && maxY >= 0) {
            int x0 = (int) mapX(0);
            int y0 = (int) mapY(0);
            g2d.fillOval(x0 - 3, y0 - 3, 6, 6);
            g2d.drawString("(0,0)", x0 + 5, y0 - 5);
        }
    }

    private void drawGraph(Graphics2D g2d) {
        if (points.size() < 2) return;

        // Линии графика
        g2d.setColor(Color.BLUE);
        for (int i = 0; i < points.size() - 1; i++) {
            Point2D.Double p1 = points.get(i);
            Point2D.Double p2 = points.get(i + 1);
            int x1 = (int) mapX(p1.x);
            int y1 = (int) mapY(p1.y);
            int x2 = (int) mapX(p2.x);
            int y2 = (int) mapY(p2.y);
            g2d.drawLine(x1, y1, x2, y2);
        }

        // Маркеры точек
        for (Point2D.Double p : points) {
            drawMarker(g2d, p);
        }
    }

    private void drawMarker(Graphics2D g2d, Point2D.Double p) {
        int x = (int) mapX(p.x);
        int y = (int) mapY(p.y);

        // Проверка условия: целая часть y чётная
        boolean evenInteger = (Math.floor(p.y) % 2 == 0);

        // Цвет маркера
        if (highlightEvenIntegerPoints && evenInteger) {
            g2d.setColor(Color.RED);
        } else {
            g2d.setColor(Color.BLUE);
        }

        // Маркер 11x11, центр в (x, y)
        int size = 11;
        int offset = size / 2;
        g2d.fillRect(x - offset, y - offset, size, size);

        // Обводка
        g2d.setColor(Color.BLACK);
        g2d.drawRect(x - offset, y - offset, size, size);

        // Точка в центре для лучшей видимости
        g2d.setColor(Color.WHITE);
        g2d.fillOval(x - 2, y - 2, 4, 4);
    }

    private void drawZoomRectangle(Graphics2D g2d) {
        if (zoomRect != null) {
            // Устанавливаем пунктирную линию
            Stroke dashed = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL,
                    0, new float[]{5}, 0);
            g2d.setStroke(dashed);
            g2d.setColor(Color.RED);
            g2d.drawRect(zoomRect.x, zoomRect.y, zoomRect.width, zoomRect.height);

            // Возвращаем обычный стиль
            g2d.setStroke(new BasicStroke());
        }
    }

    private void drawTooltip(Graphics2D g2d) {
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(tooltipText);
        int textHeight = fm.getHeight();

        // Рисуем фон подсказки
        g2d.setColor(new Color(255, 255, 200, 220));
        g2d.fillRect(tooltipPoint.x, tooltipPoint.y - textHeight,
                textWidth + 6, textHeight + 4);

        // Рисуем рамку
        g2d.setColor(Color.BLACK);
        g2d.drawRect(tooltipPoint.x, tooltipPoint.y - textHeight,
                textWidth + 6, textHeight + 4);

        // Текст
        g2d.drawString(tooltipText, tooltipPoint.x + 3, tooltipPoint.y - 3);
    }

    private double mapX(double x) {
        return getWidth() * (x - minX) / (maxX - minX);
    }

    private double mapY(double y) {
        return getHeight() * (1 - (y - minY) / (maxY - minY));
    }

    private double inverseMapX(int screenX) {
        return minX + (maxX - minX) * screenX / getWidth();
    }

    private double inverseMapY(int screenY) {
        return minY + (maxY - minY) * (1 - screenY / (double)getHeight());
    }
}