import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;

public class MainFrame extends JFrame {
    private final GraphPanel graphPanel;
    private JCheckBoxMenuItem highlightMenuItem;
    private JMenuItem resetZoomMenuItem;

    public MainFrame() {
        setTitle("Graph Application with Zoom and Tooltips");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Панель графика
        graphPanel = new GraphPanel();
        add(graphPanel, BorderLayout.CENTER);

        // Создаем панель с подсказками
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("ЛКМ: выделение области | ПКМ: сброс масштаба | Наведите на точку для координат"));
        add(infoPanel, BorderLayout.SOUTH);

        // Меню
        createMenuBar();

        // Пример данных
        loadSampleData();
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // Меню График
        JMenu graphMenu = new JMenu("График");

        highlightMenuItem = new JCheckBoxMenuItem("Выделять чётные целые точки");
        highlightMenuItem.addActionListener(e ->
                graphPanel.setHighlightEvenIntegerPoints(highlightMenuItem.isSelected())
        );

        graphMenu.add(highlightMenuItem);
        graphMenu.addSeparator();

        // Меню Масштаб
        JMenu zoomMenu = new JMenu("Масштаб");

        JMenuItem zoomAreaItem = new JMenuItem("Выделить область");
        zoomAreaItem.addActionListener(e -> showZoomInstructions());

        resetZoomMenuItem = new JMenuItem("Восстановить масштаб (ПКМ)");
        resetZoomMenuItem.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Используйте правую кнопку мыши на графике для восстановления масштаба",
                    "Восстановление масштаба",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        zoomMenu.add(zoomAreaItem);
        zoomMenu.add(resetZoomMenuItem);

        // Меню Помощь
        JMenu helpMenu = new JMenu("Помощь");
        JMenuItem aboutItem = new JMenuItem("О программе");
        aboutItem.addActionListener(e -> showAboutDialog());

        helpMenu.add(aboutItem);

        menuBar.add(graphMenu);
        menuBar.add(zoomMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);
    }

    private void showZoomInstructions() {
        JOptionPane.showMessageDialog(this,
                "Инструкция по масштабированию:\n\n" +
                        "1. Наведите курсор в левый верхний угол области\n" +
                        "2. Нажмите левую кнопку мыши\n" +
                        "3. Протяните курсор до правого нижнего угла области\n" +
                        "4. Отпустите кнопку мыши\n\n" +
                        "Для восстановления масштаба нажмите правую кнопку мыши.",
                "Масштабирование графика",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAboutDialog() {
        JOptionPane.showMessageDialog(this,
                "Графическое приложение с функциями:\n\n" +
                        "• Отображение графика функции\n" +
                        "• Маркеры точек 11x11 пикселей\n" +
                        "• Подсветка точек с чётной целой частью Y\n" +
                        "• Подсказки с координатами при наведении\n" +
                        "• Масштабирование выделенной области\n" +
                        "• Восстановление масштаба правой кнопкой мыши\n\n" +
                        "Вариант B",
                "О программе",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadSampleData() {
        ArrayList<Point2D.Double> points = new ArrayList<>();
        double minX = -10, maxX = 10, minY = -5, maxY = 15;

        // Функция: квадратичная парабола с некоторыми особенностями
        for (double x = minX; x <= maxX; x += 0.2) {
            double y = 0.5 * x * x - 2 * x + 1; // функция с целыми и нецелыми значениями
            points.add(new Point2D.Double(x, y));
        }

        graphPanel.setPoints(points, minX, maxX, minY, maxY);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}