import java.io.*;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class Main {

    static class InvalidDataException extends RuntimeException {
        public InvalidDataException(String message) {
            super(message);
        }
    }

    public static void main(String[] args) {
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\User\\OneDrive\\Рабочий стол\\Лабы Java\\второй сем\\лаба 2\\src\\numbers_with_locale.txt"));

            String line;
            double sum = 0;
            int count = 0;

            while ((line = reader.readLine()) != null) {


                if (line.trim().isEmpty()) {
                    throw new InvalidDataException("Пустая строка");
                }

                String[] parts = line.split(" ");
                if (parts.length != 2) {
                    throw new InvalidDataException("Некорректная строка: " + line);
                }

                String numberPart = parts[0];
                String localePart = parts[1];

                Locale locale;

                switch (localePart) {
                    case "en":
                        locale = Locale.US;
                        break;
                    case "de":
                        locale = Locale.GERMANY;
                        break;
                    case "fr":
                        locale = Locale.FRANCE;
                        break;
                    default:
                        throw new InvalidDataException("Неизвестная локаль: " + localePart);
                }

                NumberFormat format = NumberFormat.getInstance(locale);
                Number number = format.parse(numberPart);

                double value = number.doubleValue();

                if (Double.isInfinite(value) || Double.isNaN(value)) {
                    throw new InvalidDataException("Недопустимое значение: " + value);
                }

                sum += value;
                count++;


            }

            System.out.println("Сумма: " + sum);
            System.out.println("Среднее: " + (sum / count));

        } catch (FileNotFoundException e) {
            throw new InvalidDataException("Файл не найден");
        } catch (ParseException | IllegalArgumentException e) {
            throw new InvalidDataException("Ошибка обработки строки: ");
        } catch (IOException e) {
            throw new InvalidDataException("Ошибка ввода-вывода");

        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                System.out.println("Ошибка при закрытии файла");
            }
        }
    }
}