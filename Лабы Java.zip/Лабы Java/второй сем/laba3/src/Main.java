import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {


        String a = "a";
        a += "a";
        a += "b";

        System.out.println(a);



        StringBuilder sbb = new StringBuilder();
        sbb.append("a");
        sbb.append("a");
        sbb.append("b");
        System.out.println(sbb);

        BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Введите номер задания (1-8): ");
        int task = Integer.parseInt(console.readLine());

        String inputFile;
        String outputFile = "output.txt";

        switch (task) {
            case 2:
            case 6:
                inputFile = "poemMax.txt";
                break;
            case 7:
                inputFile = "ohota.txt";
                break;
            case 8:
                inputFile = "poemAdam.txt";
                break;
            default:
                inputFile = "input.txt";
        }

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        String line;

        while ((line = reader.readLine()) != null) {
            String result = processLine(line, task);
            if (result != null) {
                writer.write(result);
                writer.newLine();
            }
        }

        reader.close();
        writer.close();

        System.out.println("Готово. Результат в output.txt");
    }

    static String processLine(String line, int task) {
        switch (task) {
            case 1:
                return removeSubstring(line, "test");
            case 2:
                return replaceSubstring(line, "И", "And");
            case 3:
                return wordsStartingWithVowel(line);
            case 4:
                return matchingWords(line);
            case 5:
                return String.valueOf(maxDigits(line));
            case 6:
                return frequencyFromList(line, new String[]{"и", "в", "не"});
            case 7:
                return capitalizeWords(line);
            case 8:
                return frequencyLettersWords(line);
            default:
                return line;
        }
    }

    static String removeSubstring(String line, String sub) {
        return line.replace(sub, "");
    }

    static String replaceSubstring(String line, String oldSub, String newSub) {
        return line.replace(oldSub, newSub);
    }

    static String wordsStartingWithVowel(String line) {
        String[] words = line.split("\\s+");
        String vowels = "аеёиоуыэюяAEIOUYaeiouy";
        StringBuilder sb = new StringBuilder();

        for (String w : words) {
            if (!w.isEmpty() && vowels.indexOf(w.charAt(0)) != -1) {
                sb.append(w).append(" ");
            }
        }
        return sb.toString().trim();
    }

    static String matchingWords(String line) {
        String[] words = line.split("\\s+");
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < words.length - 1; i++) {
            String a = words[i];
            String b = words[i + 1];
            if (!a.isEmpty() && !b.isEmpty()) {
                if (a.charAt(a.length() - 1) == b.charAt(0)) {
                    sb.append(a).append(" ").append(b).append(" | ");
                }
            }
        }
        return sb.toString();
    }

    static int maxDigits(String line) {
        int max = 0;
        int current = 0;

        for (char c : line.toCharArray()) {
            if (Character.isDigit(c)) {
                current++;
                if (current > max) max = current;
            } else {
                current = 0;
            }
        }
        return max;
    }

    static String frequencyFromList(String line, String[] targetWords) {

        Map<String, Integer> map = new HashMap<>();

        for (String t : targetWords) {
            map.put(t.toLowerCase(), 0);
        }

        String[] words = line.toLowerCase().split("[^а-яa-zё]+");

        for (String w : words) {
            if (map.containsKey(w)) {
                map.put(w, map.get(w) + 1);
            }
        }

        List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort(Comparator.comparingInt(Map.Entry::getValue));

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : list) {
            sb.append(e.getKey()).append(":").append(e.getValue()).append(" ");
        }

        return sb.toString();
    }

    static String capitalizeWords(String line) {
        String[] words = line.split("\\s+");
        StringBuilder sb = new StringBuilder();

        for (String w : words) {
            if (w.length() > 0) {
                sb.append(Character.toUpperCase(w.charAt(0)));
                if (w.length() > 1) sb.append(w.substring(1));
                sb.append(" ");
            }
        }
        return sb.toString().trim();
    }

    static String frequencyLettersWords(String line) {
        Map<Character, Integer> letters = new HashMap<>();
        Map<String, Integer> words = new HashMap<>();

        for (char c : line.toCharArray()) {
            if (Character.isLetter(c)) {
                letters.put(c, letters.getOrDefault(c, 0) + 1);
            }
        }

        for (String w : line.toLowerCase().split("\\W+")) {
            if (!w.isEmpty()) {
                words.put(w, words.getOrDefault(w, 0) + 1);
            }
        }

        return "Letters: " + letters.toString() + " Words: " + words.toString();
    }
}