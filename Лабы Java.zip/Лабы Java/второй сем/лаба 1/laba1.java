import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class laba1 {

    public static class Task1 {

        public static String replaceKthLetter(String text, int k, char replacement) {
            if (text == null || text.isEmpty() || k < 1) return text;
            
            String[] words = text.split("\\s");
            StringBuilder result = new StringBuilder();
            
            for (String word : words) {
                if (word.matches("[a-zA-Zа-яА-Я]+") && word.length() >= k) {
                    char[] chars = word.toCharArray();
                    chars[k - 1] = replacement;
                    result.append(new String(chars)).append(" ");
                } else {
                    result.append(word).append(" ");
                }
            }
            return result.toString();
        }
    }

    public static class Task2 {
        public static void printLettersWithNumbers(String text) {
            // Поддерживаем русский и английский алфавиты
            String upperCase = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯABCDEFGHIJKLMNOPQRSTUVWXYZ";
            
            StringBuilder lettersLine = new StringBuilder();
            StringBuilder numbersLine = new StringBuilder();
            
            for (char c : text.toCharArray()) {
                if (Character.isLetter(c)) {
                    char upperChar = Character.toUpperCase(c);
                    int index = upperCase.indexOf(upperChar);
                    
                    if (index >= 0 && index < 33) {
                        int number = index + 1; // Номер в алфавите с 1
                        lettersLine.append(c).append("  ");
                        numbersLine.append(number).append(" ");
                        
                        // Выравнивание по количеству цифр
                        if (number < 10) {
                            numbersLine.append(" ");
                        }
                    }
                    if (index >= 33) {
                        int number = index + 1; // Номер в алфавите с 1
                        lettersLine.append(c).append("  ");
                        numbersLine.append(number - 33).append(" ");
                        
                        // Выравнивание по количеству цифр
                        if (number < 43) {
                            numbersLine.append(" ");
                        }
                    }
                    
                } else {
                    lettersLine.append(c).append(" ");
                    numbersLine.append("  ");
                }
            }
            
            System.out.println(lettersLine);
            System.out.println(numbersLine);
        }

    }

    public static class Task3 {
        public static String fixText(String text) {
            if (text == null || text.isEmpty()) return text;
            
            StringBuilder result = new StringBuilder();
            String[] words = text.split("\\s");
            
            for (String word : words) {
                if (word.matches("[а-яА-Я]+")) {
                    result.append(fixWord(word)).append(" ");
                } else {
                    result.append(word).append(" ");
                }
            }
            return result.toString();
        }
        
        private static String fixWord(String word) {
            StringBuilder fixed = new StringBuilder(word);
            for (int i = 0; i < word.length() - 1; i++) {
                char current = word.charAt(i);
                char next = word.charAt(i + 1);
                
                if (Character.toUpperCase(current) == 'Р' && 
                    Character.toUpperCase(next) == 'А') {
                    fixed.setCharAt(i + 1, Character.isLowerCase(next) ? 'о' : 'О');
                }
            }
            return fixed.toString();
        }

    }

    public static class Task4 {
        public static String insertAfterKthChar(String text, int k, String substring) {
            if (text == null || substring == null) return text;
            if (k < 0 || k > text.length()) return text + substring;
            
            return text.substring(0, k) + substring + text.substring(k);
        }

    }

    public static class Task5 {
        public static String insertAfterWords(String text, String suffix, String wordToInsert) {
            if (text == null || text.isEmpty()) return text;
            
            String[] words = text.split("\\s+");
            StringBuilder result = new StringBuilder();
            
            for (int i = 0; i < words.length; i++) {
                result.append(words[i]);
                
                if (words[i].endsWith(suffix)) {
                    result.append(" ").append(wordToInsert);
                }
                
                if (i < words.length - 1) {
                    result.append(" ");
                }
            }
            
            return result.toString();
        }

    }

    public static class Task6 {
        public static String processText(String text, int flag, char symbol, int k) {
            if (text == null) return null;
            
            String[] lines = text.split("\\s");
            StringBuilder result = new StringBuilder();
            
            for (String line : lines) {
                if (flag == 0) {
                    // Удалить символ
                    result.append(line.replace(String.valueOf(symbol), ""));
                } else {
                    // Вставить после k-го символа
                    if (k >= 0 && k <= line.length()) {
                        result.append(line, 0, k)
                              .append(symbol)
                              .append(line.substring(k));
                    } else {
                        result.append(line);
                    }
                }
                result.append("\n");
            }
            
            return result.toString().trim();
        }

    }

    public static class Task7 {
        public static String cleanText(String text) {
            if (text == null || text.isEmpty()) return text;
            
            // Заменяем все не-буквы и не-пробелы на пробелы
            String cleaned = text.replaceAll("[^a-zA-Zа-яА-Я\\s]", " ");
            
            // Заменяем множественные пробелы одним
            cleaned = cleaned.replaceAll("\\s+", " ");
            
            return cleaned.strip();
        }

    }

    public static class Task8 {
        public static String removeBetween(String text, char start, char end) {
            if (text == null || text.isEmpty()) return text;
            
            StringBuilder result = new StringBuilder();
            boolean inRemoval = false;
            
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                
                if (c == start && !inRemoval) {
                    inRemoval = true;
                } else if (c == end && inRemoval) {
                    inRemoval = false;
                } else if (!inRemoval) {
                    result.append(c);
                }
            }
            
            return result.toString();
        }

    }

    public static class Task9 {
        public static void countWordFrequency(String text) {
            if (text == null || text.isEmpty()) {
                System.out.println("Текст пуст");
                return;
            }
            
            // Приводим к нижнему регистру и удаляем знаки препинания
            text = text.toLowerCase();
            text = text.replaceAll("[^a-zA-Zа-яА-Я\\s]", " ");
            text = text.replaceAll("\\s+", " ").trim();
            
            // Разбиваем на слова
            String[] words = text.split(" ");
            
            // Создаем массивы для хранения уникальных слов и их счетчиков
            String[] uniqueWords = new String[words.length];
            int[] counts = new int[words.length];
            int uniqueCount = 0;
            
            // Подсчитываем частоту слов
            for (String word : words) {
                if (word.isEmpty()) continue;
                
                boolean found = false;
                for (int i = 0; i < uniqueCount; i++) {
                    if (uniqueWords[i].equals(word)) {
                        counts[i]++;
                        found = true;
                        break;
                    }
                }
                
                if (!found) {
                    uniqueWords[uniqueCount] = word;
                    counts[uniqueCount] = 1;
                    uniqueCount++;
                }
            }
            
            // Выводим результат
            for (int i = 0; i < uniqueCount; i++) {
                System.out.println("  '" + uniqueWords[i] + "': " + counts[i] + " раз(а)");
            }
        }
    }

    public static class Task10 {
    
        public static void findMostFrequentChars(String text, int n) {
            if (text == null || text.isEmpty()) {
                System.out.println("Текст пуст");
                return;
            }
            
            if (n <= 0) {
                System.out.println("n должно быть положительным числом");
                return;
            }
            
            // Массив для подсчета символов (поддерживаем Unicode до 65535)
            int[] charCounts = new int[65536];
            
            // Подсчитываем каждый символ
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                charCounts[c]++;
            }
            
            // Создаем массивы для хранения символов и их частот
            char[] chars = new char[charCounts.length];
            int[] counts = new int[charCounts.length];
            int uniqueCount = 0;
            
            // Собираем только те символы, которые встречаются
            for (int i = 0; i < charCounts.length; i++) {
                if (charCounts[i] > 0) {
                    chars[uniqueCount] = (char) i;
                    counts[uniqueCount] = charCounts[i];
                    uniqueCount++;
                }
            }

            // Сортируем по убыванию частоты (пузырьковая сортировка)
            for (int i = 0; i < uniqueCount - 1; i++) {
                for (int j = 0; j < uniqueCount - i - 1; j++) {
                    if (counts[j] < counts[j + 1]) {
                        // Меняем местами counts
                        int tempCount = counts[j];
                        counts[j] = counts[j + 1];
                        counts[j + 1] = tempCount;

                        // Меняем местами соответствующие символы
                        char tempChar = chars[j];
                        chars[j] = chars[j + 1];
                        chars[j + 1] = tempChar;
                    }
                }
            }
            
            // Выводим результат
            int limit = Math.min(n, uniqueCount);
            System.out.println("Топ " + limit + " наиболее частых символов:");
            
            for (int i = 0; i < limit; i++) {
                char c = chars[i];
                String displayChar;
                
                // Специальная обработка для пробелов и непечатных символов
                if (c == ' ') {
                    displayChar = "пробел";
                } else if (c == '\n') {
                    displayChar = "\\n";
                } else if (c == '\t') {
                    displayChar = "\\t";
                } else if (c == '\r') {
                    displayChar = "\\r";
                } else {
                    displayChar = "'" + c + "'";
                }
                
                System.out.println("  " + (i + 1) + ". " + displayChar + 
                                 " - " + counts[i] + " раз(а)");
            }
        }

    }
   
    public static void main(String[] args) {


        String a = "ololo";
        String b = "olo"+"lo";
        String c = new String(a);

        System.out.println(a==b);
        System.out.println(a==c);
        System.out.println(b==c);

        String number = "+375 (29) 385-33-88";

        String regex = "^(\\+375) \\((29|25|33|44)\\) (\\d{3}-\\d{2}-\\d{2})$";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(number);

        if (matcher.matches()) {
            System.out.println("Номер подходит под стандарт");
            System.out.println("Код страны: " + matcher.group(1));   // +375
            System.out.println("Код оператора: " + matcher.group(2)); // 29
            System.out.println("Номер телефона: " + matcher.group(3)); // 385-33-88
        } else {
            System.out.println("Номер не подходит под стандарт");
        }
        

        // Тестовый текст
        String text = "работа с текстом в Java! Это очень интересно...";

        System.out.println("Исходный текст: " + text + "\n");

        // Задача 1
        System.out.println("1. Замена 3-й буквы на '*':");
        System.out.println("   " + Task1.replaceKthLetter(text, 3, '*') + "\n");

        // Задача 2
        System.out.println("2. Номера букв в алфавите:");
        Task2.printLettersWithNumbers("Hello");
        System.out.println();

        // Задача 3
        System.out.println("3. Исправление 'А' на 'О' после 'Р':");
        System.out.println("   " + Task3.fixText("работа трава") + "\n");

        // Задача 4
        System.out.println("4. Вставка подстроки после 5-го символа:");
        System.out.println("   " + Task4.insertAfterKthChar("Hello world", 5, " beautiful") + "\n");

        // Задача 5
        System.out.println("5. Вставка слова после слов на 'от':");
        System.out.println("   " + Task5.insertAfterWords("кот порт плот рот", "от", "слово") + "\n");

        // Задача 6
        System.out.println("6. Удаление/вставка символа:");
        System.out.println("   " + Task6.processText("Hello World", 1, 'l', 2) + "\n");

        // Задача 7
        System.out.println("7. Очистка текста:");
        System.out.println("   " + Task7.cleanText("Hello, world! Java 8 - best!!!") + "\n");

        // Задача 8
        System.out.println("8. Удаление между символами:");
        System.out.println("   " + Task8.removeBetween("Hello (world) Java", '(', ')') + "\n");

        // Задача 9
        System.out.println("9. Частота слов:");
        Task9.countWordFrequency("кот, кот/ пес кот");
        System.out.println();

        // Задача 10
        System.out.println("10. Наиболее частые символы:");
        Task10.findMostFrequentChars("aabbb   cccc", 3);
    }
}
