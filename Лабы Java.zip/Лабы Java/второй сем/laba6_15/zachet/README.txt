Запуск проекта:
1. Открыть проект в IntelliJ IDEA как Maven project.
2. Установить Tomcat 10.x.
3. Добавить конфигурацию Tomcat Local.
4. В Deployment добавить artifact: calculator:war exploded.
5. Запустить сервер и открыть http://localhost:8080/calculator/
