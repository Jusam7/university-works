package com.computers;

import com.computers.comparator.DeviceCriticalComparator;
import com.computers.comparator.DeviceNameComparator;
import com.computers.comparator.DevicePriceComparator;
import com.computers.model.Device;
import com.computers.parser.DeviceDOMParser;
import com.computers.parser.DeviceSAXParser;
import com.computers.parser.DeviceStAXParser;
import com.computers.transform.DeviceXSLTransformer;
import com.computers.validator.DeviceXSDValidator;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Entry point demonstrating all required functionality:
 *  1. XSD validation
 *  2. SAX / DOM / StAX parsing
 *  3. Sorting with Comparator
 *  4. XSL transformation
 */
public class Main {

    public static void main(String[] args) throws Exception {

        // ── 1. XSD VALIDATION ────────────────────────────────────────────
        System.out.println("=== XSD Validation ===");
        DeviceXSDValidator validator = new DeviceXSDValidator();
        boolean valid = validator.validate(
                res("devices.xml"),
                res("devices.xsd")
        );
        System.out.println("XML is valid: " + valid);
        System.out.println();

        // ── 2. SAX PARSING ───────────────────────────────────────────────
        System.out.println("=== SAX Parser ===");
        List<Device> saxDevices = new DeviceSAXParser().parse(res("devices.xml"));
        printDevices(saxDevices);

        // ── 3. DOM PARSING ───────────────────────────────────────────────
        System.out.println("=== DOM Parser ===");
        List<Device> domDevices = new DeviceDOMParser().parse(res("devices.xml"));
        printDevices(domDevices);

        // ── 4. StAX PARSING ──────────────────────────────────────────────
        System.out.println("=== StAX Parser ===");
        List<Device> staxDevices = new DeviceStAXParser().parse(res("devices.xml"));
        printDevices(staxDevices);

        // ── 5. SORTING ───────────────────────────────────────────────────
        List<Device> devices = new ArrayList<>(saxDevices);

        System.out.println("=== Sorted by Name ===");
        devices.sort(new DeviceNameComparator());
        devices.forEach(d -> System.out.println("  " + d.getName()));

        System.out.println("=== Sorted by Price ===");
        devices.sort(new DevicePriceComparator());
        devices.forEach(d -> System.out.printf("  %-35s %,.2f RUB%n", d.getName(), d.getPrice()));

        System.out.println("=== Sorted by Critical (critical first) ===");
        devices.sort(new DeviceCriticalComparator());
        devices.forEach(d -> System.out.printf("  %-35s critical=%b%n", d.getName(), d.isCritical()));

        // ── 6. XSL TRANSFORMATION ────────────────────────────────────────
        System.out.println();
        System.out.println("=== XSL Transformation (root -> Critical) ===");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        new DeviceXSLTransformer().transform(res("devices.xml"), res("devices.xsl"), baos);
        System.out.println(baos.toString("UTF-8"));
    }

    // ------------------------------------------------------------------ //

    private static void printDevices(List<Device> list) {
        list.forEach(d -> System.out.println("  " + d));
        System.out.println();
    }

    private static InputStream res(String name) {
        InputStream is = Main.class.getClassLoader().getResourceAsStream(name);
        if (is == null) throw new RuntimeException("Resource not found: " + name);
        return is;
    }
}
