package com.computers.parser;

import com.computers.model.Device;
import com.computers.model.Device.TypeEntry;
import com.computers.model.Device.Group;
import com.computers.model.Device.Port;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * DOM-based parser for devices.xml.
 */
public class DeviceDOMParser {

    public List<Device> parse(InputStream xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(xml);
        doc.getDocumentElement().normalize();

        List<Device> devices = new ArrayList<>();
        NodeList deviceNodes = doc.getElementsByTagName("Device");

        for (int i = 0; i < deviceNodes.getLength(); i++) {
            Element el = (Element) deviceNodes.item(i);
            Device device = new Device();

            device.setName(getText(el, "Name"));
            device.setOrigin(getText(el, "Origin"));
            device.setPrice(new BigDecimal(getText(el, "Price")));
            device.setCritical(Boolean.parseBoolean(getText(el, "Critical")));

            NodeList typeNodes = el.getElementsByTagName("Type");
            for (int j = 0; j < typeNodes.getLength(); j++) {
                Element te = (Element) typeNodes.item(j);
                TypeEntry entry = new TypeEntry();
                entry.setPeripheral(Boolean.parseBoolean(getText(te, "Peripheral")));
                entry.setPowerConsumption(Integer.parseInt(getText(te, "PowerConsumption")));
                entry.setHasCooler(Boolean.parseBoolean(getText(te, "HasCooler")));
                entry.setGroup(Group.valueOf(getText(te, "Group")));
                entry.setPort(Port.valueOf(getText(te, "Port")));
                device.getTypes().add(entry);
            }
            devices.add(device);
        }
        return devices;
    }

    private String getText(Element parent, String tag) {
        NodeList nl = parent.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        return nl.item(0).getTextContent().trim();
    }
}
