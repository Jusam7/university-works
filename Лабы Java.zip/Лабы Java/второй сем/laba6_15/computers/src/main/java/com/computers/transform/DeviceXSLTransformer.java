package com.computers.transform;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Applies the XSL stylesheet to transform devices.xml →
 * a new XML document whose root element is &lt;Critical&gt;.
 */
public class DeviceXSLTransformer {

    /**
     * @param xml    source XML stream
     * @param xsl    XSL stylesheet stream
     * @param output destination for the transformed XML
     */
    public void transform(InputStream xml, InputStream xsl, OutputStream output) throws Exception {
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer(new StreamSource(xsl));
        transformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
        transformer.transform(new StreamSource(xml), new StreamResult(output));
    }
}
