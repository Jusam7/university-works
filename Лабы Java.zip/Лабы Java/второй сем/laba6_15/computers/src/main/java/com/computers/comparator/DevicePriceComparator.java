package com.computers.comparator;

import com.computers.model.Device;

import java.util.Comparator;

/** Sort by price ascending. */
public class DevicePriceComparator implements Comparator<Device> {
    @Override
    public int compare(Device d1, Device d2) {
        return d1.getPrice().compareTo(d2.getPrice());
    }
}
