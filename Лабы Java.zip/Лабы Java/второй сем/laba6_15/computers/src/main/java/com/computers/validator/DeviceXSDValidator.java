package com.computers.validator;

import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.io.InputStream;

/**
 * Validates an XML document against devices.xsd.
 */
public class DeviceXSDValidator {

    /**
     * @param xmlStream  XML to validate
     * @param xsdStream  XSD schema
     * @return true if valid, false otherwise (prints errors to stderr)
     */
    public boolean validate(InputStream xmlStream, InputStream xsdStream) {
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new StreamSource(xsdStream));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(xmlStream));
            return true;
        } catch (SAXException e) {
            System.err.println("[XSD] Validation error: " + e.getMessage());
            return false;
        } catch (IOException e) {
            System.err.println("[XSD] IO error: " + e.getMessage());
            return false;
        }
    }
}
