package com.computers.parser;

import com.computers.model.Device;
import com.computers.model.Device.TypeEntry;
import com.computers.model.Device.Group;
import com.computers.model.Device.Port;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * SAX-based parser for devices.xml.
 */
public class DeviceSAXParser {

    public List<Device> parse(InputStream xml) throws Exception {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = factory.newSAXParser();
        Handler handler = new Handler();
        parser.parse(xml, handler);
        return handler.devices;
    }

    // ------------------------------------------------------------------ //
    private static class Handler extends DefaultHandler {

        List<Device> devices = new ArrayList<>();

        private Device current;
        private TypeEntry currentType;
        private StringBuilder text = new StringBuilder();

        @Override
        public void startElement(String uri, String localName,
                                 String qName, Attributes attributes) throws SAXException {
            text.setLength(0);
            switch (qName) {
                case "Device":
                    current = new Device();
                    break;
                case "Type":
                    currentType = new TypeEntry();
                    break;
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) {
            text.append(ch, start, length);
        }

        @Override
        public void endElement(String uri, String localName, String qName) {
            String val = text.toString().trim();
            switch (qName) {
                case "Device":
                    devices.add(current);
                    current = null;
                    break;
                case "Type":
                    current.getTypes().add(currentType);
                    currentType = null;
                    break;
                case "Name":       current.setName(val); break;
                case "Origin":     current.setOrigin(val); break;
                case "Price":      current.setPrice(new BigDecimal(val)); break;
                case "Critical":   current.setCritical(Boolean.parseBoolean(val)); break;
                case "Peripheral":
                    if (currentType != null) currentType.setPeripheral(Boolean.parseBoolean(val));
                    break;
                case "PowerConsumption":
                    if (currentType != null) currentType.setPowerConsumption(Integer.parseInt(val));
                    break;
                case "HasCooler":
                    if (currentType != null) currentType.setHasCooler(Boolean.parseBoolean(val));
                    break;
                case "Group":
                    if (currentType != null) currentType.setGroup(Group.valueOf(val));
                    break;
                case "Port":
                    if (currentType != null) currentType.setPort(Port.valueOf(val));
                    break;
            }
        }
    }
}
