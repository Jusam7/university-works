package com.computers.parser;

import com.computers.model.Device;
import com.computers.model.Device.TypeEntry;
import com.computers.model.Device.Group;
import com.computers.model.Device.Port;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * StAX-based parser for devices.xml.
 */
public class DeviceStAXParser {

    public List<Device> parse(InputStream xml) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        XMLStreamReader reader = factory.createXMLStreamReader(xml);

        List<Device> devices = new ArrayList<>();
        Device current = null;
        TypeEntry currentType = null;
        String currentElement = "";

        while (reader.hasNext()) {
            int event = reader.next();

            switch (event) {
                case XMLStreamConstants.START_ELEMENT:
                    currentElement = reader.getLocalName();
                    if ("Device".equals(currentElement)) {
                        current = new Device();
                    } else if ("Type".equals(currentElement)) {
                        currentType = new TypeEntry();
                    }
                    break;

                case XMLStreamConstants.CHARACTERS:
                    if (reader.isWhiteSpace() || current == null) break;
                    String val = reader.getText().trim();
                    if (val.isEmpty()) break;

                    switch (currentElement) {
                        case "Name":             current.setName(val); break;
                        case "Origin":           current.setOrigin(val); break;
                        case "Price":            current.setPrice(new BigDecimal(val)); break;
                        case "Critical":         current.setCritical(Boolean.parseBoolean(val)); break;
                        case "Peripheral":
                            if (currentType != null) currentType.setPeripheral(Boolean.parseBoolean(val));
                            break;
                        case "PowerConsumption":
                            if (currentType != null) currentType.setPowerConsumption(Integer.parseInt(val));
                            break;
                        case "HasCooler":
                            if (currentType != null) currentType.setHasCooler(Boolean.parseBoolean(val));
                            break;
                        case "Group":
                            if (currentType != null) currentType.setGroup(Group.valueOf(val));
                            break;
                        case "Port":
                            if (currentType != null) currentType.setPort(Port.valueOf(val));
                            break;
                    }
                    break;

                case XMLStreamConstants.END_ELEMENT:
                    String endName = reader.getLocalName();
                    if ("Device".equals(endName)) {
                        devices.add(current);
                        current = null;
                    } else if ("Type".equals(endName) && current != null) {
                        current.getTypes().add(currentType);
                        currentType = null;
                    }
                    currentElement = "";
                    break;
            }
        }
        reader.close();
        return devices;
    }
}
