package com.computers.comparator;

import com.computers.model.Device;

import java.util.Comparator;

/** Sort by name (A–Z). */
public class DeviceNameComparator implements Comparator<Device> {
    @Override
    public int compare(Device d1, Device d2) {
        return d1.getName().compareTo(d2.getName());
    }
}
