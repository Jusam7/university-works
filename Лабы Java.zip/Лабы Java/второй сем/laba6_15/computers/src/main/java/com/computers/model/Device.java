package com.computers.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a computer component (Device).
 */
public class Device {

    private String name;
    private String origin;
    private BigDecimal price;
    private List<TypeEntry> types = new ArrayList<>();
    private boolean critical;

    // ---- inner types ----

    public enum Group {
        IO_DEVICE, MULTIMEDIA
    }

    public enum Port {
        COM, USB, LPT
    }

    public static class TypeEntry {
        private boolean peripheral;
        private int powerConsumption;
        private boolean hasCooler;
        private Group group;
        private Port port;

        public TypeEntry() {}

        public TypeEntry(boolean peripheral, int powerConsumption,
                         boolean hasCooler, Group group, Port port) {
            this.peripheral = peripheral;
            this.powerConsumption = powerConsumption;
            this.hasCooler = hasCooler;
            this.group = group;
            this.port = port;
        }

        public boolean isPeripheral() { return peripheral; }
        public void setPeripheral(boolean peripheral) { this.peripheral = peripheral; }

        public int getPowerConsumption() { return powerConsumption; }
        public void setPowerConsumption(int powerConsumption) { this.powerConsumption = powerConsumption; }

        public boolean isHasCooler() { return hasCooler; }
        public void setHasCooler(boolean hasCooler) { this.hasCooler = hasCooler; }

        public Group getGroup() { return group; }
        public void setGroup(Group group) { this.group = group; }

        public Port getPort() { return port; }
        public void setPort(Port port) { this.port = port; }

        @Override
        public String toString() {
            return "TypeEntry{peripheral=" + peripheral +
                    ", power=" + powerConsumption + "W" +
                    ", hasCooler=" + hasCooler +
                    ", group=" + group +
                    ", port=" + port + "}";
        }
    }

    // ---- constructors ----

    public Device() {}

    public Device(String name, String origin, BigDecimal price,
                  List<TypeEntry> types, boolean critical) {
        this.name = name;
        this.origin = origin;
        this.price = price;
        this.types = types;
        this.critical = critical;
    }

    // ---- getters / setters ----

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public List<TypeEntry> getTypes() { return types; }
    public void setTypes(List<TypeEntry> types) { this.types = types; }

    public boolean isCritical() { return critical; }
    public void setCritical(boolean critical) { this.critical = critical; }

    @Override
    public String toString() {
        return "Device{" +
                "name='" + name + '\'' +
                ", origin='" + origin + '\'' +
                ", price=" + price +
                ", types=" + types +
                ", critical=" + critical +
                '}';
    }
}
