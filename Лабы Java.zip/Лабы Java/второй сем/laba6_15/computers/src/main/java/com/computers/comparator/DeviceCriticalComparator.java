package com.computers.comparator;

import com.computers.model.Device;

import java.util.Comparator;

/** Critical devices first, then non-critical. */
public class DeviceCriticalComparator implements Comparator<Device> {
    @Override
    public int compare(Device d1, Device d2) {
        return Boolean.compare(d2.isCritical(), d1.isCritical());
    }
}
