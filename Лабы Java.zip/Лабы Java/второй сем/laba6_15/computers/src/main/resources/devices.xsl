<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>

    <!--
        Transform: root element becomes <Critical>,
        grouping devices by their Critical value.
    -->
    <xsl:template match="/">
        <Critical>
            <CriticalDevices>
                <xsl:apply-templates select="Devices/Device[Critical='true']"/>
            </CriticalDevices>
            <NonCriticalDevices>
                <xsl:apply-templates select="Devices/Device[Critical='false']"/>
            </NonCriticalDevices>
        </Critical>
    </xsl:template>

    <xsl:template match="Device">
        <Device>
            <Name><xsl:value-of select="Name"/></Name>
            <Origin><xsl:value-of select="Origin"/></Origin>
            <Price><xsl:value-of select="Price"/></Price>
            <Types>
                <xsl:for-each select="Types/Type">
                    <Type>
                        <Peripheral><xsl:value-of select="Peripheral"/></Peripheral>
                        <PowerConsumption><xsl:value-of select="PowerConsumption"/></PowerConsumption>
                        <HasCooler><xsl:value-of select="HasCooler"/></HasCooler>
                        <Group><xsl:value-of select="Group"/></Group>
                        <Port><xsl:value-of select="Port"/></Port>
                    </Type>
                </xsl:for-each>
            </Types>
        </Device>
    </xsl:template>

</xsl:stylesheet>
