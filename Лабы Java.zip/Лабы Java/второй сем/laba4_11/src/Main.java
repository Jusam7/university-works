import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class Main {

    public static void main(String[] args) throws Exception {
        System.out.println("Задание 1: Строки из файла в обратном порядке");
        task1();

        System.out.println("\nЗадание 2: Цифры числа в обратном порядке");
        task2(123456);

        System.out.println("\nЗадание 3: Каталог и подкаталоги");
        task3(".");

        System.out.println("\nЗадание 4: Стихи, сортировка по длине строк");
        task4();

        System.out.println("\nЗадание 5: Обмен двух стеков");
        task5();

        System.out.println("\nЗадание 6: Пересечение и объединение множеств");
        task6();

        System.out.println("\nЗадание 7: МНК для нахождения сопротивления R");
        task7();

        System.out.println("\nЗадание 8: Попарное суммирование ряда");
        task8();

        System.out.println("\nЗадание 9: Сложение многочленов (HashMap)");
        task9();

        System.out.println("\nЗадание 10: Умножение многочленов (List)");
        task10();
    }

    // Задание 1: Ввести строки из файла, записать в список. Вывести строки в файл в обратном порядке
    static void task1() throws IOException {

        Path inputFile = Files.createTempFile("input", ".txt");
        Files.write(inputFile, List.of("Строка первая", "Строка вторая", "Строка третья", "Строка четвёртая"));

        List<String> lines = Files.readAllLines(inputFile);
        System.out.println("Исходный список: " + lines);

        Collections.reverse(lines);

        Path outputFile = Files.createTempFile("output", ".txt");
        Files.write(outputFile, lines);

        System.out.println("Обратный порядок: " + lines);
        System.out.println("Записано в файл: " + outputFile);
    }

    // Задание 2: Цифры числа в стек, вывести число с цифрами в обратном порядке.
    static void task2(long number) {
        Stack<Integer> stack = new Stack<>();
        long n = Math.abs(number);

        while (n > 0) {
            stack.push((int)(n % 10));
            n /= 10;
        }

        StringBuilder sb = new StringBuilder();
        if (number < 0) sb.append('-');
        while (!stack.isEmpty()) {
            sb.append(stack.pop());
        }

        System.out.println("Исходное число:  " + number);
        System.out.println("Обратное число:  " + Long.parseLong(sb.toString()));
    }

    // Задание 3: Список файлов каталога и подкаталогов (через Files.walk).
    static void task3(String rootPath) throws IOException {
        List<String> fileList;
        try (Stream<Path> walk = Files.walk(Path.of(rootPath))) {
            fileList = walk
                    .map(Path::toString)
                    .collect(Collectors.toList());
        }

        System.out.println("Найдено элементов: " + fileList.size());

        fileList.stream().limit(10).forEach(System.out::println);
        if (fileList.size() > 10) System.out.println("... и ещё " + (fileList.size() - 10) + " элементов");
    }

    // Задание 4: Список стихотворений одного автора, сортировка по длине строк.
    static void task4() {
        List<String> poem = new ArrayList<>(List.of(
                "Буря мглою небо кроет,",
                "Вихри снежные крутя;",
                "То, как зверь, она завоет,",
                "То заплачет, как дитя.",
                "То по кровле обветшалой",
                "Вдруг соломой зашумит,",
                "То, как путник запоздалый,",
                "К нам в окошко застучит."
        ));

        System.out.println("До сортировки:");
        poem.forEach(System.out::println);

        poem.sort(Comparator.comparingInt(String::length));

        System.out.println("\nПосле сортировки по длине строк:");
        poem.forEach(line -> System.out.println("(" + line.length() + ") " + line));
    }

    // Задание 5: Два стека — поменять информацию местами.
    static void task5() {
        Stack<Integer> stack1 = new Stack<>();
        Stack<Integer> stack2 = new Stack<>();

        stack1.addAll(List.of(1, 2, 3, 4, 5));
        stack2.addAll(List.of(10, 20, 30));

        System.out.println("stack1 до: " + stack1);
        System.out.println("stack2 до: " + stack2);

        List<Integer> temp = new ArrayList<>();
        for (int i = stack1.size(); i > 0; i--)
        {
            temp.add(stack1.pop());
        }
        System.out.println(temp);
        for (int i = stack2.size(); i > 0; i--)
        {
            stack1.push(stack2.pop());
        }
        for (int i = stack2.size() - 1; i >= 0; i--)
        {
            stack2.push(temp.get(i));
        }

        System.out.println("stack1 после: " + stack1);
        System.out.println("stack2 после: " + stack2);
    }

    // Задание 6: Множества целых чисел — пересечение и объединение.
    static Set<Integer> intersection(Set<Integer> a, Set<Integer> b) {
        return a.stream().peek(s-> System.out.println(s))
                .map(s -> new Integer(s))
                .filter(b::contains).collect(Collectors.toSet());
    }

    static Set<Integer> union(Set<Integer> a, Set<Integer> b) {
        Set<Integer> result = new HashSet<>(a);
        result.addAll(b);
        return result;
    }

    static void task6() {
        Set<Integer> setA = new HashSet<>(Set.of(1, 2, 3, 4, 5, 6));
        Set<Integer> setB = new HashSet<>(Set.of(4, 5, 6, 7, 8, 9));

        System.out.println("Множество A: " + new TreeSet<>(setA));
        System.out.println("Множество B: " + new TreeSet<>(setB));
        System.out.println("Пересечение: " + new TreeSet<>(intersection(setA, setB)));
        System.out.println("Объединение: " + new TreeSet<>(union(setA, setB)));
    }

    // Задание 7: МНК для нахождения R при U = I * R.
    static void task7() {

        List<Double> current  = List.of(0.5, 1.0, 1.5, 2.0, 2.5);
        List<Double> voltage  = List.of(2.4, 4.9, 7.6, 9.9, 12.4);

        int n = current.size();
        double sumIU = 0, sumI2 = 0;
        for (int i = 0; i < n; i++) {
            sumIU += current.get(i) * voltage.get(i);
            sumI2 += current.get(i) * current.get(i);
        }

        double R = sumIU / sumI2;
        System.out.printf("Ток (I):       %s А%n", current);
        System.out.printf("Напряжение (U):%s В%n", voltage);
        System.out.printf("R (МНК) = %.4f Ом%n", R);
    }

    // Задание 8: Попарное суммирование ряда чисел через LinkedList(Queue).
    static void task8() {
        LinkedList<Integer> queue = new LinkedList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8));
        ArrayList<Integer> queue2 = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8));

        System.out.println(queue instanceof Deque<Integer>);
//        System.out.println(queue2 instanceof Deque<Integer>);
        System.out.println("Исходный ряд: " + queue);

        int step = 1;
        while (queue.size() > 1) {
            LinkedList<Integer> next = new LinkedList<>();
            while (queue.size() >= 2) {
                next.add(queue.poll() + queue.poll());
            }
            if (!queue.isEmpty()) next.add(queue.poll());
            System.out.println("Шаг " + step++ + ": " + next);
            queue = next;
        }

        System.out.println("Результат: " + queue.getFirst());
    }

    // Задание 9: Сложение двух многочленов (коэффициенты в HashMap).
    static void task9() {
        Map<Integer, Double> p = new HashMap<>(Map.of(2, 3.0, 1, 2.0, 0, 1.0));
        Map<Integer, Double> q = new HashMap<>(Map.of(3, 1.0, 2, -3.0, 0, 4.0));

        System.out.println("P(x) = " + polyToString(p));
        System.out.println("Q(x) = " + polyToString(q));

        Map<Integer, Double> sum = new HashMap<>(p);
//        q.forEach((degree, coef) ->
//                sum.merge(degree, coef, Double::sum));
        for (Map.Entry<Integer, Double> entry : q.entrySet()) {
            int degree = entry.getKey();
            double coef = entry.getValue();

            double oldCoef = sum.getOrDefault(degree, 0.0);
            sum.put(degree, oldCoef + coef);
        }

        sum.entrySet().removeIf(e -> e.getValue() == 0);

        System.out.println("P(x)+Q(x) = " + polyToString(sum));
    }

    // Задание 10: Умножение двух многочленов (коэффициенты в ArrayList).
    static void task10() {
        // p.get(i) — коэффициент при x^i
        List<Double> p = new ArrayList<>(List.of(3.0, 2.0, 1.0)); // 3 + 2x + x²
        List<Double> q = new ArrayList<>(List.of(4.0, 1.0));       // 4 + x

        int degreeProduct = (p.size() - 1) + (q.size() - 1);
        List<Double> product = new ArrayList<>(degreeProduct + 1);
        for (int i = 0; i <= degreeProduct; i++) {
            product.add(0.0);
        }
        //List<Double> product = new ArrayList<>(Collections.nCopies(degreeProduct + 1, 0.0));

        for (int i = 0; i < p.size(); i++) {
            for (int j = 0; j < q.size(); j++) {
                product.set(i + j, product.get(i + j) + p.get(i) * q.get(j));
            }
        }

        System.out.println("P(x) = " + listPolyToString(p));
        System.out.println("Q(x) = " + listPolyToString(q));
        System.out.println("P(x)*Q(x) = " + listPolyToString(product));
    }

    //  Вспомогательные методы для вывода многочленов
    static String polyToString(Map<Integer, Double> poly) {
        return poly.entrySet().stream()
                .sorted((a, b) -> b.getKey() - a.getKey())
                .map(e -> {
                    double c = e.getValue();
                    int    d = e.getKey();
                    String coef = (c == (long) c) ? String.valueOf((long) c) : String.valueOf(c);
                    if (d == 0) return coef;
                    if (d == 1) return coef + "x";
                    return coef + "x^" + d;
                })
                .collect(Collectors.joining(" + "))
                .replace("+ -", "- ");
    }

    // Многочлен из List (индекс = степень) → строка
    static String listPolyToString(List<Double> poly) {
        StringBuilder sb = new StringBuilder();
        for (int i = poly.size() - 1; i >= 0; i--) {
            double c = poly.get(i);
            if (c == 0) continue;
            String coef = (c == (long) c) ? String.valueOf((long) c) : String.valueOf(c);
            if (!sb.isEmpty()) sb.append(c > 0 ? " + " : " - ");
            else if (c < 0)    sb.append("-");
            sb.append(Math.abs(c) == (long) Math.abs(c)
                    ? String.valueOf((long) Math.abs(c)) : String.valueOf(Math.abs(c)));
            if (i == 1) sb.append("x");
            else if (i > 1) sb.append("x^").append(i);
        }
        return sb.isEmpty() ? "0" : sb.toString();
    }
}