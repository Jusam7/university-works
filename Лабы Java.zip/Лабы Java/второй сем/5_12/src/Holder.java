import java.util.concurrent.atomic.AtomicInteger;

public class Holder{
    AtomicInteger i = new AtomicInteger(0);

    public AtomicInteger getI() {
        return i;
    }

    public void setI(int i) {
        this.i =  new AtomicInteger(i);;
    }
}