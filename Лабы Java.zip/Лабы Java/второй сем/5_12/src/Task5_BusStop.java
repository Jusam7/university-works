import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

class BusStop {
    private final String name;
    private final int maxBuses;
    private final Semaphore slots;
    private final AtomicInteger current = new AtomicInteger(0);

    public BusStop(String name, int maxBuses) {
        this.name = name;
        this.maxBuses = maxBuses;
        this.slots = new Semaphore(maxBuses, true);
    }

    public void arrive(String busName) throws InterruptedException {
        slots.acquire(); // ждём свободное место на остановке
        current.incrementAndGet();
        System.out.printf("[%s] прибыл на ост. \"%s\". Автобусов: %d/%d%n",
                busName, name, current.get(), maxBuses);
    }

    public void depart(String busName) {
        current.decrementAndGet();
        slots.release();
        System.out.printf("[%s] отправился с ост. \"%s\". Автобусов: %d/%d%n",
                busName, name, current.get(), maxBuses);
    }

    public String getName()    { return name; }
    public int getCurrent()    { return current.get(); }
    public int getMaxBuses()   { return maxBuses; }
}

class Bus extends Thread {
    private final List<BusStop> route;
    private final Holder h;

    public Bus(String name, List<BusStop> route, Holder h) {
        super(name);
        this.route = route;
        this.h = h;
    }
    Thread t = new Thread(() -> {
        // то же самое что в run()
    }, "Автобус-1");

    @Override
    public void run() {
        h.getI().incrementAndGet();
//        ThreadLocalRandom rnd = ThreadLocalRandom.current();
//        System.out.printf("[%s] Начинает маршрут (%d остановок)%n", getName(), route.size());
//        try {
//            for (BusStop stop : route) {
//                Thread.sleep(rnd.nextLong(200, 500)); // едем до остановки
//                stop.arrive(getName());
//                Thread.sleep(rnd.nextLong(300, 700)); // стоим, посадка/высадка
//                stop.depart(getName());
//            }
//            System.out.printf("[%s] Завершил маршрут%n", getName());
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
    }
}
class BusRunnable implements Runnable {
    private final List<BusStop> route;

    public BusRunnable(List<BusStop> route) {
        this.route = route;
    }

    @Override
    public void run() {
        // та же логика маршрута
    }
}


public class Task5_BusStop {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        List<BusStop> stops = List.of(
                new BusStop("Центр",       2),
                new BusStop("Рынок",       3),
                new BusStop("Университет", 2),
                new BusStop("Больница",    2),
                new BusStop("Конечная",    4)
        );
        Thread t = new Thread(new BusRunnable(stops), "Автобус-1");
        t.start();
        Holder h = new Holder();

        ExecutorService pool = Executors.newFixedThreadPool(7);

        Future<String> future = pool.submit(() -> {
            // логика маршрута
            return "Автобус-1 завершил маршрут"; // может вернуть результат!
        });

        String result = future.get(); // блокирует пока не выполнится
        pool.shutdown();

        System.out.printf("Автобусные остановки: %d остановок, 7 автобусов%n%n",
                stops.size());

        List<Bus> buses = new ArrayList<>();
        for (int i = 1; i <= 700; i++)
            buses.add(new Bus("Автобус-" + i, stops, h));

        for (Bus b : buses) {
            b.start();
            //Thread.sleep(80);
            }

        for (Bus b : buses) b.join();

        System.out.println(h.getI());
        System.out.println("\nМаршрут завершён.");
    }
}

