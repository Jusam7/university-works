INSERT INTO LIKES (user_id, track_id, like_date)
VALUES (2, 4, CURDATE());
