CREATE INDEX idx_track_title ON TRACKS(track_title);
