SELECT u.username, t.track_title, l.like_date
FROM USERS u
LEFT JOIN LIKES l ON u.user_id = l.user_id
LEFT JOIN TRACKS t ON l.track_id = t.track_id
ORDER BY u.username;
