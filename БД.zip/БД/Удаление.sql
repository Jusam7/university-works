DELETE FROM LIKES
WHERE user_id = 3 AND track_id = 3;
