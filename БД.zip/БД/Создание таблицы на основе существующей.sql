CREATE TABLE ROCK_TRACKS AS
SELECT t.*, g.genre_name
FROM TRACKS t
JOIN GENRES g ON t.genre_id = g.genre_id
WHERE g.genre_name = 'Rock';
