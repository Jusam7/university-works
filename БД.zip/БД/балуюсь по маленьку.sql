select tracks.track_title, tracks.duration_seconds, (concat(tracks.duration_seconds/60), ".", tracks.duration_seconds%60) as duration_minutes
from tracks