SELECT g.genre_name, COUNT(*) AS track_count
FROM TRACKS t
JOIN GENRES g ON t.genre_id = g.genre_id
GROUP BY g.genre_name
HAVING COUNT(*) > 1;
