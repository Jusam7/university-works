ALTER TABLE artists drop CONSTRAINT ck_artyear;
ALTER TABLE artists ADD CONSTRAINT ck_artyear CHECK (formation_year between 1890 and 2025);
ALTER TABLE albums drop CONSTRAINT ck_albyear;
ALTER TABLE albums ADD CONSTRAINT ck_albyear CHECK (release_year between 1890 and 2025);

ALTER TABLE users ADD CONSTRAINT ck_email CHECK (email like '%_@%_.%_');

ALTER TABLE likes ADD CONSTRAINT ck_likedate CHECK (like_date between '2000-01-01' and '2026-01-01');

ALTER TABLE playlists ADD CONSTRAINT ck_plstdate CHECK (created_date between '2000-01-01' and '2026-01-01');
