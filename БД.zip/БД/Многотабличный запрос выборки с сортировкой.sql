SELECT t.track_title, a.album_title, ar.artist_name, g.genre_name, a.release_year
FROM TRACKS t
JOIN ALBUMS a ON t.album_id = a.album_id
JOIN ARTISTS ar ON a.artist_id = ar.artist_id
JOIN GENRES g ON t.genre_id = g.genre_id
WHERE g.genre_name = 'Rock'
ORDER BY a.release_year ASC;
