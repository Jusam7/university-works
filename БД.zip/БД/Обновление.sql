UPDATE ARTISTS
SET country = 'United States'
WHERE artist_id = 1;
