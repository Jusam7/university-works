CREATE VIEW v_tracks_with_artists AS
SELECT t.track_title, a.album_title, ar.artist_name
FROM TRACKS t
JOIN ALBUMS a ON t.album_id = a.album_id
JOIN ARTISTS ar ON a.artist_id = ar.artist_id;
