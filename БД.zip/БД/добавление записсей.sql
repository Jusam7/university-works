INSERT INTO playlist_tracks (playlist_id, track_id, added_date, position) VALUES
(1, 2, '2023-01-01', 1),  -- playlist_id = 1, track_id = 2
(1, 3, '2023-01-01', 2),  -- playlist_id = 1, track_id = 3
(2, 4, '2023-02-01', 1);  -- playlist_id = 2, track_id = 4