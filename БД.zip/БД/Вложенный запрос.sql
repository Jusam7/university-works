SELECT track_title
FROM TRACKS
WHERE genre_id = (SELECT genre_id FROM GENRES WHERE genre_name = 'Pop');
