SELECT 
    track_title,
    duration_seconds,
    CONCAT(FLOOR(duration_seconds / 60), ' мин ', duration_seconds % 60, ' сек') AS formatted_duration
FROM TRACKS;
