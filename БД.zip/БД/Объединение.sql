SELECT artist_name AS name FROM ARTISTS
UNION
SELECT username AS name FROM USERS;
