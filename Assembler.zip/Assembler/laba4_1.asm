.data
a dq 2
b dq 4
c dq 5
y sqword ?

.code

cube PROC
    ; rcx = a
    mov rax, rcx
    imul rax, rcx
    imul rax, rcx
    ret
cube ENDP

div3 PROC
    ; rcx = value
    mov rax, rcx
    cqo
    mov rbx, 3
    idiv rbx
    ret
div3 ENDP

calc_c PROC
    ; rcx = b, rdx = c
    mov rax, rcx
    add rax, 3
    imul rax, rdx
    ret
calc_c ENDP

main PROC

    ; a^3
    mov rcx, a
    call cube

    ; (a^3)/3
    mov rcx, rax
    call div3
    mov r8, rax

    ; c*(b+3)
    mov rcx, b
    mov rdx, c
    call calc_c
    mov r9, rax

    ; y = r8 - r9
    mov rax, r8
    sub rax, r9
    mov y, rax

    ret
main ENDP

END