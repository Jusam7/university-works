.DATA
A DWORD 1, 4, 5, 6
B DWORD 2, 3, 7
CountA = ($ - A) / TYPE A
CountB = ($ - B) / TYPE B

C DWORD 0, 0, 0, 0, 0, 0

.CODE
main PROC
    lea rsi, A      
    lea rdi, B     
    lea rdx, C      
    mov rcx, CountA 
    dec rcx
    mov r8, CountB  
    dec r8
    xor r9, r9        

L_loop:
    cmp rcx, 0
    je Done
    cmp r8, 0
    je Done

    mov eax, [rsi]
    mov ebx, [rdi]
    cmp eax, ebx
    je L_equal
    jl L_A_less
    add rdi, 4
    dec r8
    jmp L_loop

L_A_less:
    add rsi, 4
    dec rcx
    jmp L_loop


L_equal:
    mov [rdx], eax
    add rdx, 4
    add rsi, 4
    add rdi, 4
    dec rcx
    dec r8
    jmp L_loop

Done:
    
    ret
main ENDP
END