.DATA
A DWORD 1,2,3, 4,5,6, 7,8,9
B DWORD 1,0,0, 0,4,0, 0,0,6
C DWORD 9 DUP(0)

N = 3

.CODE
main PROC

    xor r8d, r8d        

Outer_i:
    cmp r8d, N
    jge Done

    xor r9d, r9d        

Outer_j:
    cmp r9d, N
    jge Next_i

    xor r10d, r10d      
    xor r11d, r11d      

Loop_k1:
    cmp r11d, N
    jge Calc_BA

    ; A[i][k]
    mov eax, r8d
    imul eax, N
    add eax, r11d
    shl eax, 2
    lea rsi, A
    add rsi, rax
    mov eax, DWORD PTR [rsi]

    ; B[k][j]
    mov ebx, r11d
    imul ebx, N
    add ebx, r9d
    shl ebx, 2
    lea rdi, B
    add rdi, rbx
    mov ebx, DWORD PTR [rdi]

    imul eax, ebx
    add r10d, eax

    inc r11d
    jmp Loop_k1

Calc_BA:
    xor r11d, r11d    
    xor r12d, r12d     

Loop_k2:
    cmp r11d, N
    jge Store

    ; B[i][k]
    mov eax, r8d
    imul eax, N
    add eax, r11d
    shl eax, 2
    lea rsi, B
    add rsi, rax
    mov eax, DWORD PTR [rsi]

    ; A[k][j]
    mov ebx, r11d
    imul ebx, N
    add ebx, r9d
    shl ebx, 2
    lea rdi, A
    add rdi, rbx
    mov ebx, DWORD PTR [rdi]

    imul eax, ebx
    add r12d, eax

    inc r11d
    jmp Loop_k2

Store:
    ; C[i][j] = sum1 - sum2
    mov eax, r8d
    imul eax, N
    add eax, r9d
    shl eax, 2
    lea rsi, C
    add rsi, rax

    mov eax, r10d
    sub eax, r12d
    mov DWORD PTR [rsi], eax

    inc r9d
    jmp Outer_j

Next_i:
    inc r8d
    jmp Outer_i

Done:
    ret
main ENDP
END