.CONST

.DATA
n       SDWORD 1223
ans     BYTE ?

.CODE
main PROC
    mov eax, n
    xor ecx, ecx        
    mov ebx, eax       

outer_loop:
    cmp ebx, 0
    je check_ans

    xor edx, edx
    mov eax, ebx
    mov edi, 10
    div edi
    mov esi, edx       
    mov ebx, eax      

    mov eax, ebx
    mov edi, eax      
inner_loop:
    cmp edi, 0
    je outer_loop_continue

    xor edx, edx
    mov eax, edi
    mov edi, 10
    div edi
    cmp edx, esi
    jne inner_next
    inc ecx
inner_next:
    mov edi, eax
    jmp inner_loop

outer_loop_continue:
    jmp outer_loop

check_ans:
    cmp ecx, 1
    je two_same
    mov ans, 0
    jmp done

two_same:
    mov ans, 1

done:
    ret
main ENDP
END