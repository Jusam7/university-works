.CONST

.DATA

flag DWORD 1
x2 DWORD 2
x3 DWORD 3
x4 DWORD 4

array dword 1,2,3,4,5,6,7
el_sz = TYPE array ; = 4

.CODE
main PROC

    mov flag, 0  

finding_max:

    mov rax, [array]
    mov rbx, x2
    cmp eax, ebx
    jge skip12
    mov x1, ebx
    mov x2, eax

skip12:

    ;x2 � x3

    mov eax, x2
    mov ebx, x3
    cmp eax, ebx
    jge skip23
    mov x2, ebx
    mov x3, eax

skip23:

    ;x3 � x4

    mov eax, x3
    mov ebx, x4
    cmp eax, ebx
    jge skip34
    mov x3, ebx
    mov x4, eax

skip34:

    dec ecx
    jnz outer_loop

    ret
main ENDP
END