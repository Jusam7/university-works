.CONST

.DATA
n BYTE 3

ans BYTE ?

.CODE
main PROC

    mov cl, n
    mov al, 6
    xor bl, bl
    
    cmp cl, 0
    je endcycle

summ_loop:

    add bl, al
    add al, 6

    dec cl
    jnz summ_loop

    mov ans, bl

endcycle:
    ret
main ENDP
END