
; Двоичное кодирование числа на 4 светодиодах
; Потенциометр → A0
; LED1–LED4    → pin 8–11 (PB0–PB3)

.include "m328Pdef.inc"

.org 0x0000
    rjmp RESET


RESET:
    ; Инициализация стека
    ldi r16, high(RAMEND)
    out SPH, r16
    ldi r16, low(RAMEND)
    out SPL, r16

    ; PB0–PB3 → выходы
    in  r16, DDRB
    ori r16, (1<<DDB0)|(1<<DDB1)|(1<<DDB2)|(1<<DDB3)
    out DDRB, r16

    ; Все LED выключить
    in  r16, PORTB
    andi r16, 0b11110000
    out PORTB, r16

    ; ── Настройка АЦП ──
    ; REFS0=1 → AVcc, ADLAR=1 → 8 бит в ADCH
    ldi r16, (1<<REFS0)|(1<<ADLAR)
    sts ADMUX, r16

    ; ADEN=1, делитель 128
    ldi r16, (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)
    sts ADCSRA, r16

MAIN_LOOP:

    ; ── Запуск АЦП ──
    lds r16, ADCSRA
    ori r16, (1<<ADSC)
    sts ADCSRA, r16

WAIT_ADC:
    lds r16, ADCSRA
    sbrc r16, ADSC
    rjmp WAIT_ADC

    ; r17 = ADC результат 0–255
    lds r17, ADCH

    ; ── Делим r17 на 16 → получаем число 0–15 ──
    ; Сдвиг вправо на 4 бита = деление на 16
    lsr r17
    lsr r17
    lsr r17
    lsr r17
    ; теперь r17 = 0..15 — это и есть наше двоичное число

    ; ── Записываем в PB0–PB3 ──
    ; Сохраняем старшие биты PORTB (PB4–PB7) без изменений
    in  r16, PORTB
    andi r16, 0b11110000    ; гасим биты 0–3
    or   r16, r17           ; вставляем новое двоичное число
    out PORTB, r16

    rjmp MAIN_LOOP