.code

func PROC

    mov r10, rcx       

    mov rsi, rcx
    mov rcx, rdx
    dec rcx

    mov r8, rsi
    mov r9, rsi

L2:
    mov eax, [r8]
    mov edx, [rsi]
    cmp edx, eax
    jle L3
    mov r8, rsi
L3:
    add rsi, 4
    dec rcx
    jnz L2

    mov rsi, r10
    mov rcx, rdx

MIN2:
    mov eax, [r9]
    mov edx, [rsi]
    cmp edx, eax
    jge MIN3
    mov r9, rsi
MIN3:
    add rsi, 4
    loop MIN2

    xor eax, eax      

    mov rax, r9
    cmp rax, r8
    jl SUMM1
    jmp SUMM2

SUMM1:
    mov rsi, r9
INL1:
    cmp rsi, r8
    je ENDPR
    add rsi, 4
    add eax, [rsi]
    jmp INL1

SUMM2:
    mov rsi, r8
INL2:
    add rsi, 4
    cmp rsi, r9
    je ENDPR
    add eax, [rsi]
    jmp INL2

ENDPR:
    ret

func ENDP
END