includelib ucrt.lib
includelib legacy_stdio_definitions.lib

.data

arr DWORD 2, 1, 3, 4, 5, 6
Count = ($ - arr) / TYPE arr

max qword ?
min qword ?

answer dword 0

fmtStr db "answer = %d",10,0

.code

externdef printf:PROC

main PROC

	mov rcx, Count
	dec rcx

	lea rsi, arr

	mov max, rsi
	mov min, rsi		

L2:
    mov rax, max
    mov eax, [rax]
    mov edx, [rsi]
    cmp edx, eax
    jle L3
    mov max, rsi
L3:
    add rsi, 4
	dec rcx
	jnz L2

	lea rsi, arr
	mov rcx, Count

MIN2:
    mov rax, min
    mov eax, [rax]
    mov edx, [rsi]
    cmp edx, eax
    jge MIN3
    mov min, rsi
MIN3:
    add rsi, 4
    loop MIN2

    mov rax, min
	cmp rax, max
	jl SUMM1
	jmp SUMM2

SUMM1:
    mov rsi, min

INL1:
	cmp rsi, max
	je PRINT
	add rsi, 4
	mov eax, [rsi]
	add answer, eax
	jmp INL1

SUMM2:
    mov rsi, max

INL2:
	add rsi, 4
	cmp rsi, min
	je PRINT
	mov eax, [rsi]
	add answer, eax
	jmp INL2

PRINT:
	sub rsp, 8       
	sub rsp, 32        

	mov edx, answer
	lea rcx, fmtStr

	call printf

	add rsp, 32
	add rsp, 8

	xor rax, rax
	ret

main ENDP
END