.CONST

.DATA

k BYTE 6
l BYTE 7
m BYTE 3
n BYTE 3

ans BYTE ? ;0 - ��� �������� (�����), 1 - ����� �������, 2 - ����� �� ��������

.CODE
main PROC

    mov al, k
    cmp al, m
    je rook_x_queen
    mov al, l
    cmp al, n
    je rook_x_queen


    mov al, k
    add al, l
    mov bl, al

    mov al, m
    add al, n
    cmp al, bl
    je queen_kill

    mov al, k
    sub al, l
    mov bl, al
    neg bl
    cmp al, 0
    jge abs1
    mov al, bl

abs1:
    mov bl, m
    sub bl, n
    mov cl, bl
    neg cl
    cmp bl, 0
    jge abs2
    mov bl, cl
abs2:

    cmp al, bl
    je queen_kill

    mov ans, 2
    jmp done

    mov al, m
    sub al, n
    cmp al, bl
    je queen_kill


    rook_x_queen:
        mov ans, 0
        jmp done

queen_kill:
    mov ans, 1    
    jmp done

done:
    ret
main ENDP
END