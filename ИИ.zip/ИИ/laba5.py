import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.datasets import make_moons
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt


# ══════════════════════════════════════════════════════════════════════
# ПРАКТИЧЕСКАЯ ЧАСТЬ — пример на датасете make_moons
# ══════════════════════════════════════════════════════════════════════

# Генерируем синтетический набор данных (две луны)
X, y = make_moons(n_samples=1000, noise=0.2, random_state=42)

# Разделяем на тренировочную и тестовую выборки
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Нормализация данных
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

# Создание многослойного перцептрона (MLP)
# Скрытые слои: 16 нейронов → 8 нейронов, активация relu, выход sigmoid
model = MLPClassifier(
    hidden_layer_sizes=(16, 8),
    activation='relu',
    solver='adam',
    batch_size=16,
    max_iter=50,
    random_state=42,
    verbose=True
)

# Обучение модели
model.fit(X_train, y_train)

# Оценка модели
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))

# График изменения функции ошибки
plt.figure(figsize=(7, 4))
plt.plot(model.loss_curve_, label='Training Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Кривая потерь — MLP (make_moons)')
plt.legend()
plt.tight_layout()
plt.show()

# Сравнение с классическими алгоритмами
# Логистическая регрессия
lr = LogisticRegression()
lr.fit(X_train, y_train)
y_pred_lr = lr.predict(X_test)
print("Logistic Regression Accuracy:", accuracy_score(y_test, y_pred_lr))

# Случайный лес
rf = RandomForestClassifier(n_estimators=100)
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)
print("Random Forest Accuracy:", accuracy_score(y_test, y_pred_rf))


# ══════════════════════════════════════════════════════════════════════
# ЗАДАНИЕ — "Выборы президента"
# ══════════════════════════════════════════════════════════════════════

# --- Генерация и сохранение данных ---
np.random.seed(42)
X_votes = np.random.randint(0, 2, size=(100, 12))  # 100 примеров, 12 бинарных признаков
Y_votes = np.random.randint(0, 2, size=(100, 2))   # 100 примеров, 2 класса (one-hot encoding)

np.savetxt('dataIn.txt',  X_votes, fmt='%d')
np.savetxt('dataOut.txt', Y_votes, fmt='%d')

# --- Подготовка данных ---
# Y_votes — one-hot: [1,0] = правящая партия, [0,1] = оппозиция
# Переводим в метки классов для обучения
y_labels = np.argmax(Y_votes, axis=1)

X_tr, X_te, y_tr, y_te = train_test_split(
    X_votes, y_labels, test_size=0.25, random_state=42
)

scaler2 = StandardScaler()
X_tr = scaler2.fit_transform(X_tr)
X_te = scaler2.transform(X_te)

# --- Нейросеть с одним скрытым слоем и функцией активации logsig (logistic = sigmoid) ---
model_votes = MLPClassifier(
    hidden_layer_sizes=(10,),   # один скрытый слой, 10 нейронов
    activation='logistic',      # logsig = logistic (sigmoid)
    solver='adam',
    batch_size=16,
    max_iter=100,
    random_state=42,
    verbose=True
)

# --- Обучение ---
model_votes.fit(X_tr, y_tr)

# --- Проверка точности на тестовых примерах ---
y_pred_v = model_votes.predict(X_te)
print("Elections MLP Accuracy:", accuracy_score(y_te, y_pred_v))

# --- Визуализация результатов предсказаний ---
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
fig.suptitle('Задание "Выборы президента" — MLP (logsig)', fontsize=13)

# Кривые потерь
axes[0].plot(model_votes.loss_curve_, label='Train Loss')
axes[0].set_xlabel('Epochs')
axes[0].set_ylabel('Loss')
axes[0].set_title('Кривая потерь')
axes[0].legend()

# Предсказания vs истинные метки
correct   = np.sum(y_pred_v == y_te)
incorrect = np.sum(y_pred_v != y_te)
axes[1].bar(['Верно', 'Неверно'], [correct, incorrect],
            color=['steelblue', 'salmon'], edgecolor='black')
axes[1].set_ylabel('Количество примеров')
axes[1].set_title(f'Результаты предсказаний (Acc = {accuracy_score(y_te, y_pred_v):.2f})')
for i, v in enumerate([correct, incorrect]):
    axes[1].text(i, v + 0.3, str(v), ha='center', fontweight='bold')

plt.tight_layout()
plt.savefig('elections_results.png', dpi=150)
plt.show()