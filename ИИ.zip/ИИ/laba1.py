import pandas as pd
from sklearn.preprocessing import MinMaxScaler

files = [
    "Titanic.csv"
]

datasets = {}

for file in files:
    df = pd.read_csv(file, low_memory=False)
    datasets[file] = df

print("Данные из датасетов:")
for name, df in datasets.items():
    print("\n", name)
    print(df.head())


print("\nКоличество пропущенных значений:")
for name, df in datasets.items():
    print("\n", name)
    print(df.isnull().sum())


print("\nЗаполнение пропущенных значений:")

for name, df in datasets.items():

    for column in df.columns:

        if df[column].dtype == "object" or df[column].dtype == "string":
            mode_value = df[column].mode()
            if len(mode_value) > 0:
                df[column] = df[column].fillna(mode_value[0])

        else:
            if df[column].isnull().sum() > 0:
                if abs(df[column].skew()) > 1:
                    df[column] = df[column].fillna(df[column].median())
                else:
                    df[column] = df[column].fillna(df[column].mean())

    print("\nПосле заполнения:", name)
    print(df.isnull().sum())


print("\nНормализация числовых данных:")

scaler = MinMaxScaler()

for name, df in datasets.items():
    numeric_cols = df.select_dtypes(include=['int64','float64']).columns
    if len(numeric_cols) > 0:
        df[numeric_cols] = scaler.fit_transform(df[numeric_cols])


print("Нормализация выполнена")


print("\nПреобразование категориальных данных:")

for name, df in datasets.items():

    categorical_cols = df.select_dtypes(include=['object','string']).columns

    safe_cols = []

    for col in categorical_cols:
        if df[col].nunique() < 50:
            safe_cols.append(col)

    if len(safe_cols) > 0:
        df = pd.get_dummies(df, columns=safe_cols, drop_first=True)

    datasets[name] = df

print("Категориальные признаки преобразованы")


print("\nПример обработанных данных:")
for name, df in datasets.items():
    print("\n", name)
    print(df.head())


for name, df in datasets.items():
    df.to_csv("processed_" + name, index=False)

print("\nОбработанные датасеты сохранены")