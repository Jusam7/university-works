import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, precision_score, recall_score, f1_score

df = pd.read_csv("Titanic.csv")

df = df.drop(columns=["Name", "Cabin", "PassengerId"], errors="ignore")

df["Age"] = df["Age"].fillna(df["Age"].median())

for col in ["HomePlanet", "Destination"]:
    if col in df.columns:
        df[col] = df[col].fillna(df[col].mode()[0])

bool_cols = ["CryoSleep", "VIP"]
for col in bool_cols:
    if col in df.columns:
        df[col] = df[col].fillna(0)
        df[col] = df[col].astype(int)

df = pd.get_dummies(df, columns=["HomePlanet", "Destination"], drop_first=True)
df = df.fillna(0)

y_reg = df["Age"]
X_reg = df.drop(columns=["Age"])

Xr_train, Xr_test, yr_train, yr_test = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=42
)

reg_model = LinearRegression()
reg_model.fit(Xr_train, yr_train)
y_reg_pred = reg_model.predict(Xr_test)

print("РЕГРЕССИЯ (Возраст)")
print("Среднеквадратичная ошибка (MSE):", mean_squared_error(yr_test, y_reg_pred))
print("Коэффициент детерминации (R²):", r2_score(yr_test, y_reg_pred))
print()

df["Transported"] = df["Transported"].fillna(0).astype(int)

y_clf = df["Transported"]
X_clf = df.drop(columns=["Transported", "Age"])

scaler = StandardScaler()
X_train, X_test, y_train, y_test = train_test_split(
    X_clf, y_clf, test_size=0.2, random_state=42
)

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

clf_model = LogisticRegression(max_iter=500, random_state=42)
clf_model.fit(X_train_scaled, y_train)

y_clf_pred = clf_model.predict(X_test_scaled)

print("КЛАССИФИКАЦИЯ (Transported)")
print("Точность (Accuracy):", accuracy_score(y_test, y_clf_pred))
print("Прецизионность (Precision):", precision_score(y_test, y_clf_pred))
print("Полнота (Recall):", recall_score(y_test, y_clf_pred))
print("F1-мера:", f1_score(y_test, y_clf_pred))