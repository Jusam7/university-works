import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, plot_tree
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    accuracy_score,
    roc_curve,
    auc,
    classification_report
)

df = pd.read_csv('processed_Titanic.csv')

df_model = df.drop(['PassengerId', 'Name', 'Cabin'], axis=1)
df_model['Transported'] = df_model['Transported'].astype(int)

print("\nЗАДАЧА РЕГРЕССИИ")

X_reg = df_model.drop('Age', axis=1)
y_reg = df_model['Age']

X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=42
)

dt_reg = DecisionTreeRegressor(max_depth=5, random_state=42)
dt_reg.fit(X_train_reg, y_train_reg)

y_pred_reg = dt_reg.predict(X_test_reg)

mae_reg = mean_absolute_error(y_test_reg, y_pred_reg)
rmse_reg = np.sqrt(mean_squared_error(y_test_reg, y_pred_reg))

print(f"Средняя абсолютная ошибка (MAE): {mae_reg:.4f}")
print(f"Корень из средней квадратичной ошибки (RMSE): {rmse_reg:.4f}")

print("\nЗАДАЧА КЛАССИФИКАЦИИ")

X_cls = df_model.drop('Transported', axis=1)
y_cls = df_model['Transported']

X_train_cls, X_test_cls, y_train_cls, y_test_cls = train_test_split(
    X_cls, y_cls, test_size=0.2, random_state=42
)

dt_cls = DecisionTreeClassifier(max_depth=5, criterion='gini', random_state=42)
dt_cls.fit(X_train_cls, y_train_cls)

y_pred_cls = dt_cls.predict(X_test_cls)
y_proba_cls = dt_cls.predict_proba(X_test_cls)[:, 1]

print(f"Точность (Accuracy): {accuracy_score(y_test_cls, y_pred_cls):.4f}")
print("Отчёт по классификации:")
print(classification_report(y_test_cls, y_pred_cls))

fpr, tpr, thresholds = roc_curve(y_test_cls, y_proba_cls)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2,
         label=f'ROC-кривая (площадь = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('Доля ложноположительных (FPR)')
plt.ylabel('Доля истинноположительных (TPR)')
plt.title('ROC-кривая')
plt.legend(loc="lower right")
plt.grid(alpha=0.3)
plt.show()

plt.figure(figsize=(20,10))
plot_tree(
    dt_cls,
    feature_names=X_cls.columns,
    class_names=['Остался', 'Перемещён'],
    filled=True,
    max_depth=3,
    fontsize=10
)
plt.title("Визуализация структуры дерева")
plt.show()