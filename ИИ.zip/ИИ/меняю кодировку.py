# пробуем сначала как UTF-16 (судя по виду текста — вероятный вариант)
with open('ohota.txt', 'r', encoding='utf-16') as f:
    text = f.read()

with open('ohota_utf8.txt', 'w', encoding='utf-8') as f:
    f.write(text)