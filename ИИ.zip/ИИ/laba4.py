import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve, classification_report

df = pd.read_csv('processed_Titanic.csv')

df = df.drop(columns=['PassengerId', 'Cabin', 'Name'], errors='ignore')
df = df.fillna(df.median(numeric_only=True))

y = df['Transported']
X = df.drop(columns=['Transported'])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=None,
    oob_score=True,
    random_state=42,
    n_jobs=-1
)

rf.fit(X_train, y_train)

y_pred_rf = rf.predict(X_test)
y_prob_rf = rf.predict_proba(X_test)[:, 1]

print("СЛУЧАЙНЫЙ ЛЕС")
print("OOB оценка:", rf.oob_score_)
print("Точность:", accuracy_score(y_test, y_pred_rf))
print("ROC AUC:", roc_auc_score(y_test, y_prob_rf))
print(classification_report(y_test, y_pred_rf))

ada = AdaBoostClassifier(
    n_estimators=200,
    learning_rate=0.5,
    random_state=42
)

ada.fit(X_train, y_train)

y_pred_ada = ada.predict(X_test)
y_prob_ada = ada.predict_proba(X_test)[:, 1]

print("\nADABOOST")
print("Точность:", accuracy_score(y_test, y_pred_ada))
print("ROC AUC:", roc_auc_score(y_test, y_prob_ada))
print(classification_report(y_test, y_pred_ada))

gb = GradientBoostingClassifier(
    n_estimators=200,
    learning_rate=0.1,
    max_depth=3,
    random_state=42
)

gb.fit(X_train, y_train)

y_pred_gb = gb.predict(X_test)
y_prob_gb = gb.predict_proba(X_test)[:, 1]

print("\nГРАДИЕНТНЫЙ БУСТИНГ")
print("Точность:", accuracy_score(y_test, y_pred_gb))
print("ROC AUC:", roc_auc_score(y_test, y_prob_gb))
print(classification_report(y_test, y_pred_gb))

fpr_rf, tpr_rf, _ = roc_curve(y_test, y_prob_rf)
fpr_ada, tpr_ada, _ = roc_curve(y_test, y_prob_ada)
fpr_gb, tpr_gb, _ = roc_curve(y_test, y_prob_gb)

plt.figure()
plt.plot(fpr_rf, tpr_rf, label='Случайный лес')
plt.plot(fpr_ada, tpr_ada, label='AdaBoost')
plt.plot(fpr_gb, tpr_gb, label='Градиентный бустинг')

plt.plot([0, 1], [0, 1], linestyle='--')

plt.xlabel('Доля ложноположительных')
plt.ylabel('Доля истинноположительных')
plt.title('ROC-кривые')
plt.legend()

plt.show()