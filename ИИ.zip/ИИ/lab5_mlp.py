import numpy as np
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

np.random.seed(42)

X = np.random.randint(0, 2, size=(100, 12))

first_half  = X[:, :6].sum(axis=1)   # сумма первых 6 ответов
second_half = X[:, 6:].sum(axis=1)   # сумма последних 6 ответов

labels = (first_half <= second_half).astype(int)

Y = np.zeros((100, 2), dtype=int)
Y[labels == 0, 0] = 1
Y[labels == 1, 1] = 1

np.savetxt('dataIn.txt',  X, fmt='%d')
np.savetxt('dataOut.txt', Y, fmt='%d')

X = np.loadtxt('dataIn.txt')
Y = np.loadtxt('dataOut.txt')

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.3, random_state=42
)

model = keras.Sequential()

model.add(keras.layers.Dense(
    8,
    activation='sigmoid',
    input_shape=(12,)
))

model.add(keras.layers.Dense(
    2,
    activation='softmax'
))

model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

history = model.fit(
    X_train,
    Y_train,
    epochs=50,
    batch_size=8,
    validation_data=(X_test, Y_test)
)

loss, accuracy = model.evaluate(X_test, Y_test)
print("Точность модели:", accuracy)

pred = model.predict(X_test)
pred_classes = np.argmax(pred, axis=1)
true_classes = np.argmax(Y_test, axis=1)

acc = accuracy_score(true_classes, pred_classes)
print("Accuracy:", acc)

for i in range(10):
    print("Ответ модели:", pred_classes[i], "Правильный ответ:", true_classes[i])

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.xlabel('Эпохи')
plt.ylabel('Ошибка')
plt.legend(['Train Loss', 'Val Loss'])
plt.show()